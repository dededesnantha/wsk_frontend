<?php
 // * This can be set to anything, but default usage is:
 // *     development
 // *     testing
 // *     production
define('APP_DEBUG','development');
define('BASE_URL','http://localhost/travel_CODEIGNITER_demo2');
define('AWS_PATH','https://d3uyff779abz3k.cloudfront.net/crud/');

define('DB_HOST','localhost');
define('DB_DATABASE','travel_db(4)');
define('DB_USERNAME','root');
define('DB_PASSWORD','');

define('MAIL_DRIVER','smtp');
define('MAIL_HOST','mail.tayatha.com');
define('MAIL_PORT','26');
define('MAIL_USERNAME','localhost@tayatha.com');
define('MAIL_PASSWORD','?2RhKP((G4p}');
define('MAIL_ENCRYPTION','ssl');

define('CAPCHA_KEY','6Lf5tmgUAAAAAJJoHUAPraxfVtTn0Xy-fG7UzTGG');
define('CAPCHA_SECRET_KEY','6Lf5tmgUAAAAAImF0p9IVDKD4k3CYNO9Y7-LsYXj');