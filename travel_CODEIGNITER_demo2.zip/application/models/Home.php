<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Model {
	// new
	public function home()
	{
		$result = $this->db->from('home_setting')
					->order_by('posisi','ASC')
					->where('status',1)
					->get()
					->result_array();
		return $result;
	}
	public function slider()
	{	
		$result = $this->db->from('slider')
					->order_by('position','ASC')
					->get()
					->result_array();
		return $result;
	}

	public function special()
	{

		$result = $this->db->from('special_offer')
							->join('product','product.id = special_offer.id_product','left')
                            ->join('page','page.id = special_offer.id_page','left')
                            ->select('product.judul as product_judul,
		                            	product.deskripsi as product_deskripsi,
			                            product.slug as product_slug,
			                            product.gambar as product_gambar,
			                            product.price as product_price,
			                            page.judul as page_judul,
		                                page.deskripsi as page_deskripsi,
		                                page.slug as page_slug,
		                                page.gambar as page_gambar')
                            ->order_by('special_offer.position','ASC')
                            ->get()
                            ->result_array();
		return $result;
	}
	public function product()
	{
		$result = $this->db->from('kategori')
                    ->select('judul,
                    		seo_deskripsi,
                    		gambar,
                    		slug')
                    ->where('status',1)
                    ->order_by('position','ASC')
                    ->get()
					->result_array();                    
		return $result;                                
	}


	public function transport()
	{
		$result = $this->db->from('page')
					->select('judul,
							gambar,
							deskripsi')
					->where('status',1)
					->where('display','transport')
					->get()
					->result_array();
		return $result;
	}
	public function review()
	{
		$result = $this->db->from('review')					
					->where('deleted_at IS NULL',null)
					->where('approve',1)
					->orderby('id','DESC')
					->limit(6)
					->get()
					->result_array();
		return $result;
	}
	public function booking()
	{	
		$result = $this->db->from('kategori')
					->select('id,
							judul,
							slug')
					->order_by('judul','ASC')
					->get()
					->result_array();
		return $result;
	}
	public function bookingData($id='')
	{
		$result = $this->db->from('product')				
				->select('judul,
					slug')
				->where('id_kategori',$id)
				->where('status',1)
				->get()
				->result_array();
		return $result;
	}
	public function search($search='',$page=1)
	{
		if ($page <= 0) {
            $page = 0;
        }else{
            $page = $page-1;
        }
        $this->load->library('pagination');
        $per_page = 14;
        $config['total_rows'] = $this->db->from('product')
                                ->select('count(*) as num')                             
                                ->where('judul LIKE','%'.$search.'%')
        						->get()
                                ->result_array()[0]['num'];
        $config['base_url'] = base_url('search'.'?search='.$search);                                
        $config['per_page'] = $per_page;
        $config['enable_query_strings'] = TRUE;
        $config['page_query_string'] = TRUE;    
        $config['query_string_segment'] = 'page';
        $config['use_page_numbers'] = TRUE;     

        $config['full_tag_open'] = '<ul class="pagination pagination-sm">';
        $config['full_tag_close'] = '</ul>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><span>';
        $config['cur_tag_close'] = '</span></li>';

        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';
        $config['next_link'] = 'Next';

        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';
        $config['prev_link'] = 'Previous';

        $config['last_link'] = FALSE;
        $config['first_link'] = FALSE;

        $this->pagination->initialize($config); 
        $result['paging'] = $this->pagination->create_links();
        $result['data'] = $this->db
                        ->where('judul LIKE','%'.$search.'%')                    
	        			->get('product',$per_page,$per_page*$page)
	                    ->result_array();   
        return $result;   
	}
	public function BookingList($value='')
	{
		$category = $this->db->from('kategori')
						->select('id,
								judul,
								slug')
						->order_by('judul','ASC')
						->get()
						->result_array();
		$result = array();
        foreach ($category as $row) {
            $result[$row['slug']]['name'] = $row['judul'];
            $result[$row['slug']]['slug'] = $row['slug'];
            $result[$row['slug']]['data'] = $this->db->from('product')
            										->select('judul,slug')
            										->where('id_kategori',$row['id'])
            										->where('status',1)
            										->get()
            										->result_array();
        }
        return $result;
	}
	public function list_review($page=1)
	{
		if ($page <= 0) {
            $page = 0;
        }else{
            $page = $page-1;
        }
        $this->load->library('pagination');
        $per_page = 14;
        $config['total_rows'] = $this->db->from('review')
                                ->select('count(*) as num')                                                            
                                ->where('deleted_at IS NULL',null)
        						->where('approve',1)
        						->get()
                                ->result_array()[0]['num'];
        $config['base_url'] = base_url('review.html');                                
        $config['per_page'] = $per_page;
        $config['enable_query_strings'] = TRUE;
        $config['page_query_string'] = TRUE;    
        $config['query_string_segment'] = 'page';
        $config['use_page_numbers'] = TRUE;     

        $config['full_tag_open'] = '<ul class="pagination pagination-sm">';
        $config['full_tag_close'] = '</ul>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><span>';
        $config['cur_tag_close'] = '</span></li>';

        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';
        $config['next_link'] = 'Next';

        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';
        $config['prev_link'] = 'Previous';

        $config['last_link'] = FALSE;
        $config['first_link'] = FALSE;

        $this->pagination->initialize($config); 
        $result['paging'] = $this->pagination->create_links();
        $result['data'] = $this->db
        						->where('deleted_at IS NULL',null)
        						->where('approve',1)
        						->order_by('id','DESC')        					
	        			->get('review',$per_page,$per_page*$page)
	                    ->result_array();   
        return $result;   
	}
}

/* End of file Home.php */
/* Location: ./application/models/Home.php */