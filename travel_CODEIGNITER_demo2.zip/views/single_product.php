    <section class="banner-post container-fluid" style="background: <?= AWS_PATH.'image/'.$single['gambar'] ?>;filter: blur(5px);position: absolute;z-index: -2;height: 300px">
    </section>
            <div class="container">            
                <div class="row">
                    <div class="c-8" style="padding-top: 50px;">
                        <div class="container-fluid">                    
                            <?php require_once('views/component/alert.php') ?>
                            <div class="bg-page" style="border-radius: 4px;box-shadow: 1px 1px 16px -2px rgba(0,0,0,.3);background: #fff">
                                <div class="slider">
                                    <ul>
                                      <li>
                                        <img src="<?= AWS_PATH.'image/'.$single['gambar'] ?>" alt="<?= $single['judul'] ?>">
                                      </li>
                                      <?php foreach ($slider as $slide): ?>
                                          <?php if ($slide['gambar'] !=  $single['gambar']): ?>
                                            <li>
                                              <img src="<?= AWS_PATH.'image/'.$slide['gambar'] ?>" alt="<?= $single['judul'] ?>">
                                            </li>                                      
                                          <?php endif ?>
                                      <?php endforeach ?>                                    
                                    </ul>
                                </div>
                                
                            </div>    
                            <?php require_once('views/component/ratting.php') ?>
                            <div class="price mt-4">
                                <div class="cards-text">
                                    <h3 class="card-title"><?= $single['judul'] ?></h3>
                                    <?php if (round($single['price']) != 0): ?>        
                                    <p style="color: crimson; margin-bottom: 0px" class="single-price">
                                        Start
                                        <span style="font-size: 30px; font-weight: 700"><?= $main['label']['Price Symbol'] ?>  <?= number_format($single['price'],0,',','.'); ?> </span>
                                        /Person
                                    </p>
                                    <?php endif ?>
                                </div>
                            </div>

                            <?php require_once('views/inc/breadcrumb.php') ?>

                            <div class="p-1 bg-white">
                                <?= $single['deskripsi'] ?>
                            </div> 
                            <div class="row" style="margin-top: 20px">                               
                                <?php if (!empty($list_page)): ?>
                                    <?php require_once('views/component/list_page.php') ?>
                                <?php endif ?>
                            </div>                    
                            <?php require_once('views/component/give_review.php') ?>                        
                            <br>                        
                            <?php require_once('views/component/tag.php') ?>
                            <hr>
                            <div>
                                <?php require_once('views/component/share.php') ?>
                                <?php require_once('views/component/contact.php') ?>
                            </div>
                        </div>

                        <!-- booking -->
                        <hr style="width: 90%; margin-left: 30px;" class="mb-5">
                        
                        <div>           
                            <div class="text-center">
                              <h2 class="color-primary" style="font-family: 'Josefin Sans', sans-serif;">
                                <?= $main['label']['Booking'] ?>
                              </h2>
                              <div class="color-primary line" style="margin-bottom: 25px"></div> 
                              <?php if ($main['component']['Single Page Booking']): ?>
                                <?php if (!$main['component']['Single Page Simple Booking']): ?>
                                  <form action="<?= base_url('single_booking') ?>" method="POST">

                                    <input type="hidden" value="<?= $single['slug_cat'] ?>" name="category">
                                    <input type="hidden" value="<?= $single['judul'] ?>" name="tour">

                                    <div class="c-12 margin-bottom">
                                      <div class="row">
                                        <div class="form-group c-3">
                                          <label for="tour"><?= $main['label']['Your Tour'] ?> :</label>
                                        </div>
                                        <div class="form-group c-9">
                                          <input class="form-control" type="text" placeholder="<?= $main['label']['Your Tour'] ?>" value="<?= $single['judul']?>" readonly="true" name="tour">
                                        </div>
                                      </div>
                                    </div>

                                    <div class="row">
                                      <div class="form-group c-6" style="display: inherit;padding-right: 6px;">
                                        <input class="form-control" type="date" placeholder="Date" required="" name="tanggal" value="<?= $_SESSION['tanggal'] ?>" id="date">
                                        <label for="date" class="form-icon"><i class="icon icon-calendar"></i></label>                                  
                                      </div>
                                      <div class="form-group c-3">                    
                                        <select name="adult" required="" class="form-control">
                                          <option value="">-- <?= $main['label']['Adult'] ?> --</option>
                                          <?php for ($i = 1;$i < 21;$i++) { ?>
                                          <option value="<?= $i ?>" <?php if (@$_SESSION['adult']  == $i):echo "selected"; endif ?>><?= $i?></option>                     
                                          <?php } ?>
                                        </select>
                                      </div>
                                      <div class="form-group c-3">                      
                                        <select name="child" class="form-control">
                                          <option value="">-- <?= $main['label']['Child'] ?> --</option>
                                          <?php for ($i = 0;$i < 11;$i++) {?>
                                          <option value="<?= $i ?>" <?php if (@$_SESSION['child'] == $i):echo "selected"; endif ?>><?= $i?></option>                      
                                          <?php } ?>
                                        </select>
                                      </div>                  
                                    </div>                    
                                    <div class="">
                                      <button class="button-primary bg-primary color-white" type="submit" style="padding: 5px 20px;font-family: 'Josefin Sans', sans-serif;"><?= $main['label']['Send Booking'] ?></button>
                                    </div>
                                  </form>
                                <?php else: ?>
                                  <form action="<?= base_url('booking') ?>" method="POST" enctype="multipart/form-data" >
                                    <div class="row">                  
                                      <div class="c-12 margin-bottom">
                                        <div class="row">
                                          <div class="form-group c-3">
                                            <label for="tour"><?= $main['label']['Your Tour'] ?> :</label>
                                          </div>
                                          <div class="form-group c-9">
                                            <input class="form-control" type="text" placeholder="<? $main['label']['Your Tour'] ?>" value="<?= $single['judul']?>" readonly="true" name="tour[]">
                                          </div>
                                        </div>
                                      </div>
                                      <div class="c-12 margin-bottom">                      
                                          <div class="text-left">
                                            <div class="mr-4">                                        
                                                <input type="radio" name="initials" value="Mr." required> Mr.
                                            </div>           
                                            <div class="mr-4">
                                                <input type="radio" name="initials" value="Mrs." required> Mrs.                                    
                                            </div>
                                          </div>
                                          <div class="row">
                                            <div class="form-group c-6">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['First Name'] ?>" required="" name="first_name">
                                            </div>
                                            <div class="form-group c-6">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['Last Name'] ?>" required="" name="last_name">
                                            </div>
                                          </div>
                                          
                                          <div class="form-group">
                                            <input class="form-control" type="email" placeholder="<?= $main['label']['Your Email'] ?>" required="" name="email">
                                          </div>
                                           <div class="form-group">
                                            <input class="form-control" type="text" placeholder="<?= $main['label']['Your Phone Number'] ?>" required="" name="phone">
                                          </div>
                                          
                                          <div class="row">
                                            <div class="form-group c-6" style="display: inherit;padding-right: 6px;">
                                              <input class="form-control" type="date" placeholder="Date" required="" name="tanggal" value="<?= @$_SESSION['tanggal'] ?>" id="date">
                                              <label for="date" class="form-icon"><i class="icon icon-calendar"></i></label>                                  
                                            </div>
                                            <div class="form-group c-3">                    
                                              <select name="adult" required="" class="form-control">
                                                <option value="">-- <?= $main['label']['Adult'] ?> --</option>
                                                <?php for ($i = 1;$i < 21;$i++) {?>
                                                <option value="<?=$i?>" <?php if (@$_SESSION['adult'] == $i):echo "selected"; endif ?>><?= $i ?></option>                      
                                                <?php } ?>
                                              </select>
                                            </div>
                                            <div class="form-group c-3">                      
                                              <select name="child" class="form-control">
                                                <option value="">-- <?= $main['label']['Child'] ?> --</option>
                                                <?php for ($i = 0;$i < 11;$i++) {?>
                                                <option value="<?=$i?>" <?php if (@$_SESSION['child'] == $i):echo "selected"; endif ?>><?= $i ?></option>                      
                                                <?php } ?>
                                              </select>
                                            </div>                  
                                          </div>    
                                          <div class="form-group">
                                            <textarea  cols="30" rows="5" class="form-control" type="text" placeholder="<?= $main['label']['Message'] ?>" name="deskripsi"></textarea>  
                                          </div>

                                          <div class="form-group">
                                            <h2 class="font-secondary" style="font-weight: 500"><?= $main['label']['Pick Up Information'] ?> : </h2>                  
                                          </div>
                                          <div class="row">
                                            <div class="form-group c-6">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['Pick Up Point'] ?>" name="pick_up_point">
                                            </div>
                                            <div class="form-group c-6">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['Your Hotel Stay'] ?>" name="hotel">
                                            </div>
                                            <div class="form-group c-6">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['Hotel Phone Number'] ?>" name="hotel_phone">
                                            </div>
                                            <div class="form-group c-6">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['Hotel Room Number'] ?>" name="hotel_room_number">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <input class="form-control" type="text" placeholder="<?= $main['label']['Your Address / Hotel Address'] ?>" required="" name="address">
                                          </div>
                                          <?php if ($main['blok_booking']): ?>
                                          <div class="form-group">
                                            <div class="g-recaptcha" data-sitekey="<?=env('CAPCHA_KEY')?>"></div>                  
                                          </div>
                                          <?php endif ?>

                                          <div class="">
                                            <button class="button-primary bg-primary color-white pull-right" type="submit" style="padding: 5px 20px;font-family: 'Josefin Sans', sans-serif;"><?= $main['label']['Submit'] ?></button>
                                          </div>
                                        
                                      </div>
                                    </div>
                                  </form>
                                <?php endif ?> 
                              <?php endif ?> 

                            </div>
                          </div>

                          <?php if ($main['component']['Review']): ?>
                              <?php require_once('views/component/review.php') ?> 
                              <?php require_once('views/component/list_review.php') ?> 
                          <?php endif ?>
                
                        <!-- end booking -->
                        <?php if ($main['component']['Comment']): ?>
                            <?php require_once('views/component/comment.php') ?>         
                        <?php endif ?>
                        <?php require_once('views/component/related_product.php') ?>
                        
                    </div>

                    <?php require_once('views/inc/sidebar.php') ?>
                </div>
            </div>



