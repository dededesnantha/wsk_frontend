<?php require_once('views/component/alert.php') ?>
<?php foreach ($home as $row): ?>
  <?php if ($row['name'] == 'Slider'): ?>
    <div class="container-fluid p-0">
        <!-- slider -->
        <div class="col-md-12 p-0">
            <div class="slider">
                <ul>
                    <?php foreach ($Slider as $slide): ?>                        
                        <li>
                            <img src="<?= AWS_PATH.'gallery/'.$slide['gambar'] ?>" alt="<?= $slide['judul'] ?>">
                            <?php if (trim($slide['judul']) != ""): ?>                            
                                <div class="color-white font-secondary bg-primary p-2">
                                    <span>
                                        <?= $slide['judul'] ?>
                                    </span>
                                </div>                        
                            <?php endif ?>                          
                        </li>
                    <?php endforeach ?>                      
                </ul>
            </div>                
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="c-8">
                <!-- profile -->
                <?php elseif ($row['name'] == 'Profile'): ?>
                    <section  style="margin-bottom: 75px;padding-top: 50px">
                      <div class="row">
                        <div class="c-12">
                          <h1 class="font-secondary color-primary" style="line-height: 1.4;margin-top: 0"><?= $row['judul'] ?></h1>
                          <div style="line-height: 1.7;letter-spacing: 1.5px;text-align: justify;">
                              <img src="<?= AWS_PATH.'image/'.$main['profile']['gambar'] ?>"alt="<?= $main['profile']['judul'] ?>" class="profile-img">
                              <?= $main['profile']['deskripsi'] ?>
                          </div>
                          </div>
                          <div class="c-6" >
                          </div>
                          <div class="c-12">
                              <div style="line-height: 1.7;letter-spacing: 1.5px;text-align: justify;">

                              </div>
                              <?php foreach ($main['social_media'] as $social_media): ?>
                                <a href="<?= $social_media['link'] ?>" title="<?= $social_media['title'] ?>"><img src="<?= $social_media['img'] ?>" alt="<?= $social_media['title'] ?>" width="40px"></a>
                            <?php endforeach ?>      
                        </div>
                    </div>
                </section>

                <!-- product -->
                <?php elseif ($row['name'] == 'Product'): ?>
                <section  style="margin-bottom: 75px">
                    <div class="row text-center">
                      <div class="c-12">          
                        <h1 id="<?= str_replace(' ','_',$row['judul'])?>" class="text-header color-primary"><?=$row['judul']?></h1>
                        <span class="line color-primary margin-bottom"> </span>
                      </div>
                    </div>
                    <div class="row">
                      <?php foreach ($Product as $produk): ?> 
                      <article class="c-6" style="margin-bottom:20px">
                        <div class="card-1"> 
                          <a href="<?= base_url('category').'/'.$produk['slug'] ?>" title="<?= $produk['judul'] ?>">
                              <img src="<?= AWS_PATH.'image/'.$produk['gambar'] ?>" style="background-size: auto; height: 400px; max-width: 500px; width: 200%; float: left" alt="<?= $produk['judul']?>">
                          </a>
                          <div>
                            <a href="<?= base_url('category').'/'.$produk['slug'] ?>" title="<?= $produk['judul'] ?>">
                              <h2 id="<?php str_replace(' ','_',$produk['judul'])?>" class="color-white font-secondary bg-primary p-2" style="display:initial;margin:0"><?= $produk['judul']?></h2>
                            </a>
                            <?php if (trim($produk['seo_deskripsi'])!= ''): ?>
                              <div>
                                <p style="color:#000">
                                  <?= substr(strip_tags($produk['seo_deskripsi']), 0,150) ?>
                                </p>
                                <div class="text-right">
                                  <a href="<?= base_url('category').'/'.$produk['slug']?>" title="<?= $produk['judul']?>" class="color-primary"><?= $main['label']['View More'] ?> <i class="icon icon-action-redo"></i></a>
                                </div>
                              </div>
                            <?php endif ?>
                          </div>
                        </div>
                      </article>
                      <?php endforeach ?>
                    </div>
                </section> 

                <!-- special -->
                <?php elseif ($row['name'] == 'Special'): ?>
                    <section  style="margin-bottom: 75px">
                        <div class="row text-center">
                          <div class="c-12">          
                            <h1 id="<?= str_replace(' ','_',$row['judul'])?>" class="text-header color-primary"><?= $row['judul'] ?></h1>
                            <span class="line color-primary margin-bottom"></span>
                        </div>
                    </div>
                    <div class="row">            
                      <?php foreach ($Special  as $spesial): ?> 
                        <article class="c-6" style="margin-bottom:20px">
                          <div class="card-2 text-center">
                            <div class="card-2-image">
                              <a href="<?= $spesial['link'] ?>" title="<?= $spesial['title']?>">
                                <img src="<?= $spesial['img_path'].$spesial['img'] ?>" alt="<?= $spesial['title'] ?>">
                                </a> 
                            </div>
                            <div style="border-left: 1px solid #d1d1d1;border-right: 1px solid #d1d1d1;border-top: 1px solid #d1d1d1;">          
                              <a href="<?= $spesial['link'] ?>" title="<?= $spesial['title']?>">
                                <h2 style="margin-top: 0;padding-top: 20px;margin-bottom: 0;" class="font-secondary color-primary"><?= $spesial['title'] ?></h2>
                            </a>
                                <div class="card-2-content" style="display: grid;">
                                    <p>
                                      <?= $spesial['description'] ?>                        
                                  </p>
                              </div>
                           </div>
                           <div style="margin: 0;">
                              <a href="<?= $spesial['link'] ?>" title="<?= $spesial['title']?>" class="card-2-button bg-primary color-white button-block p-2"><i class="icon icon-arrow-right"></i> <?= $main['label']['Read More'] ?></a>
                          </div>
                      </div>
                    </article>          
                    <?php endforeach ?>             
                </div>
            </section>

            <!-- transport -->
      <?php elseif ($row['name'] == 'Transport'): ?>
                <section  style="margin-bottom: 75px">
                    <div class="row text-center">
                        <div class="c-12">          
                            <h1 class="text-header color-primary"><?= $row['judul'] ?></h1>
                            <span class="line color-primary margin-bottom"> </span>
                        </div>
                    </div>
                    <div class="row">      
                    <?php foreach ($Transport as $key): ?>
                        <div class="c-6" style="margin-bottom:20px">
                            <div class="card-2">
                                <div class="card-2-image" style="height: 200px">
                                    <a href="<?= base_url('category').'/'.$produk['slug'] ?>" title="<?= $produk['judul'] ?>"><img src="<?= AWS_PATH.'image/'.$produk['gambar'] ?>" class="card-img-top" alt="<?= $produk['judul'] ?> "></a>  
                                </div>                  
                                <h2 id="<?= str_replace(' ','_',$key['judul'])?>" class="font-secondary color-primary text-center"><?= $key['judul'] ?></h2>                          
                                <div class="card-2-content">
                                    <div>
                                        <?= $key['deskripsi'] ?>
                                    </div>
                                    <?php if($transport_button == true) {?>
                                        <div class="text-center">
                                            <a href="<?= base_url('booking.html') ?>" title="<?= $main['label']['Booking'] ?>" class="bg-primary color-white p-2"><i class="icon icon-arrow-right"></i> <?= $main['label']['Booking'] ?></a>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach ?>
                    </div>
                </section>

                <!-- Booking -->
                <?php elseif ($row['name'] == 'Booking'): ?>
                    <?php if ($row['custom'] == 0): ?>
                    <section  style="margin-bottom: 75px;margin-top: 75px;">    
                      <div class="row">
                        <div class="c-12">
                          <form action="<?= base_url('home_booking') ?>" method="POST"> 
                            <div class="row bg-primary">
                              <div class="form-group c-2 c-sm-12"> 
                                <h2 class="color-white"><?= $row['judul']?></h2>
                              </div>
                              <div class="form-group c-4 c-sm-12" style="display: inherit;padding-right: 6px;"> 
                                <input style="margin: auto;" class="form-control " type="date" placeholder="Date" required="" name="tanggal" value="<?= date('Y-m-d');  ?>" id="date">
                                <label for="date" class="form-icon"><i class="icon icon-calendar"></i></label>              
                              </div>
                              <div class="form-group c-2 c-sm-6" style="display: inherit;">
                                <select name="adult" required="" class="form-control" style="margin: auto;">
                                  <option value="">-- <?=  $main['label']['Adult'] ?> --</option>
                                  <?php for ($i = 1;$i < 21;$i++) {?>
                                  <option value="<?= $i?>"><?= $i?></option>                  
                                  <?php } ?>
                                </select>
                              </div>
                              <div class="form-group c-2 c-sm-6" style="display: inherit;">              
                                <select name="child" class="form-control" style="margin: auto;">
                                  <option value="">-- <?=  $main['label']['Child'] ?> --</option>
                                  <?php for ($i = 0;$i < 11;$i++) {?>
                                  <option value="<?= $i ?>"><?= $i ?></option>                  
                                  <?php } ?>
                                </select>
                              </div>              
                              <div class="form-group c-2 c-sm-12" style="display: inherit;">
                                <button type="submit" class="pull-right color-primary font-secondary button-primary" style="margin: auto;margin-right: 0;"><?=  $main['label']['Booking'] ?></button>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>      
                    </section>

                <?php else: ?>

                    <section  style="margin-bottom: 75px;margin-top: 75px; background-color: #3333">
                        <div class="tab">
                            <input id="bookings" type="checkbox" name="tabs" class="acordion">
                            <label for="bookings" class="button-primary button-block bg-primary color-white"><?= $main['label']['Booking'] ?></label>
                            <div class="tab-content" style="border: none;">
                                <form action="<?= base_url('booking') ?>" method="POST" enctype="multipart/form-data" >
                                    <div class="row">
                                        <div class="c-12 margin-bottom">
                                          <h2 class="font-secondary" style="font-weight: 500"><?= $main['label']['Select Tour'] ?> : </h2>
                                          <?php foreach ($product as $key): ?>
                                              <?php if ($key['data'] != null): ?>
                                                  <div class="tab">
                                                    <input id="<?= $key['slug'] ?>" type="checkbox" name="tabs" class="acordion" <?php if($key['slug'] == @$_SESSION['category']): echo 'checked' ;endif ?>>
                                                    <label class="label" for="<?= $key['slug'] ?>"><?= $key['name'] ?></label>
                                                    <div class="tab-content">                                            
                                                      <?php foreach ($key['data'] as $row): ?>                                            
                                                        <p><input type="checkbox" value="<?= $row['judul'] ?>" name="tour[]" <?php if($row['judul'] == @$_SESSION['tour']): echo 'checked' ;endif ?> > <span><?= $row['judul'] ?></span></p>
                                                      <?php endforeach ?>                                        
                                                    </div>
                                                  </div>    
                                              <?php endif ?>
                                          <?php endforeach ?> 
                                      </div>
                                      <div class="c-12 margin-bottom">
                                          <h2 class="font-secondary" style="font-weight: 500"><?= $main['label']['Or Custom Tour'] ?> : </h2>
                                          <div class="form-group" id="input_add" style="margin-top: 10px">
                                            <input class="form-control" id="custom" name="custom_tour[]" type="text" placeholder="Your Tour">
                                          </div>
                                          <button class="button-primary bg-primary color-white pull-right" id="add" type="button" style="font-family: 'Josefin Sans', sans-serif;"><?= $main['label']['Add Tour'] ?></button>  
                                      </div>
                                      <div class="w3-row-padding ">
                                      <div class="c-12 margin-bottom">
                                          <h2 class="font-secondary" style="font-weight: 500"><?= $main['label']['Booking'] ?> : </h2>

                                          <div>                
                                              <span style="display: inline-flex;margin-right: 9px;">
                                                <input type="radio" name="initials" value="Mr." class="form-control" required id="mr"> <label for="mr">Mr.</label>
                                              </span>
                                              <span style="display: inline-flex;margin-right: 9px;">
                                                <input type="radio" name="initials" value="Mrs." class="form-control" required id="mrs"> <label for="mrs">Mrs.</label>
                                              </span>
                                          </div>
                                          <div class="row">
                                              <div class="form-group c-6">
                                                <input class="form-control" type="text" placeholder="<?= $main['label']['First Name'] ?>" required="" name="first_name">
                                              </div>
                                              <div class="form-group c-6">
                                                <input class="form-control" type="text" placeholder="<?= $main['label']['Last Name'] ?>" required="" name="last_name">
                                              </div>
                                          </div>
                                          <div class="form-group">
                                              <input class="form-control" type="email" placeholder="<?= $main['label']['Your Email'] ?>" required="" name="email">
                                          </div>
                                          <div class="form-group">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['Your Phone Number'] ?>" required="" name="phone">
                                          </div>
                                          <div class="row">
                                            <div class="form-group c-6" style="display: inherit;padding-right: 6px;">
                                              <input class="form-control" type="date" placeholder="Date" required="" name="tanggal" value="<?php if(isset($_SESSION['tanggal'])): echo $_SESSION['tanggal']; endif ?>" id="date">
                                              <label for="date" class="form-icon"><i class="icon icon-calendar"></i></label>                                  
                                            </div>
                                            <div class="form-group c-3">                    
                                              <select name="adult" required="" class="form-control">
                                                <option value="">-- <?= $main['label']['Adult'] ?> --</option>
                                                <?php for ($i = 1;$i < 21;$i++) {?>
                                                <option value="<?= $i ?>" 
                                                <?php if (@$_SESSION['adult'] == $i):echo "selected"; endif ?>><? $i ?> </option>                      
                                                <?php } ?>
                                              </select>
                                            </div>
                                            <div class="form-group c-3">                      
                                              <select name="child" required="" class="form-control">
                                                <option value="">-- <?= $main['label']['Child'] ?> --</option>
                                                <?php for ($i = 0;$i < 11;$i++) {?>
                                                <option value="<?= $i ?>" 
                                                  <?php if (@$_SESSION['child'] == $i):echo "selected"; endif ?>><? $i ?></option>                      
                                                <?php } ?>
                                              </select>
                                            </div> 
                                          </div>
                                          <div class="form-group">
                                            <textarea  cols="30" rows="5" class="form-control" type="text" placeholder="<?= $main['label']['Message'] ?> " name="deskripsi"></textarea>  
                                          </div>
                                          <div class="form-group">
                                            <h2 class="font-secondary" style="font-weight: 500"><? $main['label']['Pick Up Information'] ?> : </h2>                  
                                          </div>
                                          <div class="row">
                                            <div class="form-group c-6">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['Pick Up Point'] ?>" name="pick_up_point">
                                            </div>
                                            <div class="form-group c-6">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['Your Hotel Stay'] ?>" name="hotel">
                                            </div>
                                            <div class="form-group c-6">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['Hotel Phone Number'] ?>" name="hotel_phone">
                                            </div>
                                            <div class="form-group c-6">
                                              <input class="form-control" type="text" placeholder="<?= $main['label']['Hotel Room Number'] ?>" name="hotel_room_number">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <input class="form-control" type="text" placeholder="<?= $main['label']['Your Address / Hotel Address'] ?>" required="" name="address">
                                          </div>
                                          <?php if ($main['blok_booking']): ?>
                                            <div class="form-group">
                                              <div class="g-recaptcha" data-sitekey="<?= CAPCHA_KEY ?>"></div>               
                                            </div>
                                          <?php endif ?>
                                          <div class="">
                                            <button class="button-primary bg-primary color-white pull-right" type="submit" style="padding: 5px 20px;font-family: 'Josefin Sans', sans-serif;"><?= $main['label']['Submit'] ?></button>
                                          </div>

                                      </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                <?php endif ?>
            </div> <!-- col- 8 -->
            <?php require_once('views/inc/sidebar.php') ?> 
        </div>
    </div>
<?php endif ?>
<?php endforeach ?> 