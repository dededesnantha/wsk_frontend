        <!-- content -->
        <div class="container">            
            <div class="row">
                <div class="c-8">                    
                    <?php require_once('views/component/alert.php') ?>
                    <?php require_once('views/inc/breadcrumb.php') ?>
                    <h1 class="card-title " style="margin-bottom: 40px;">
                        Result Search                                
                    </h1>
                    <!-- list content -->
                    <div class="row">
                        <?php require_once('views/component/list_product.php') ?>                
                        <div class="col-12 text-center" style="display: flex;">
                            <?= $list['paging'] ?>
                        </div>
                    </div>                
                </div>                 
                <?php require_once('views/inc/sidebar.php') ?>
            </div>
        </div>