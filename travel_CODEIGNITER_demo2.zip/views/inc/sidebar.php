            
            <div class="c-4">
                <div class="container" style="height: 100%;position: absolute;background: #f9f9f9;border-left: 2px solid #efefef;z-index: -1"></div>
                <?php foreach ($sidebar as $row): ?>    
                    <?php if ($row['role'] == 1): ?>
                        <div class="p-1 color-primary" style="margin-bottom: 10px">
                            <?php if ($row['judul']): ?>                                
                            <div class="card-body-1 mt-4">
                                <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                                    <?= $row['judul'] ?>                    
                              </h2>
                            </div>
                            <?php endif ?>
                            <div>
                                <?php foreach ($main['social_media'] as $social_media): ?>
                                    <a href="<?= $social_media['link'] ?>" title="<?= $social_media['title'] ?>">
                                        <img src="<?= $social_media['img'] ?>" alt="<?= $social_media['title'] ?>" width="40px">
                                    </a>
                                <?php endforeach ?>
                            </div>
                        </div>
                    <?php elseif($row['role'] == 2): ?>
                        <div class="p-1 color-primary" style="margin-bottom: 10px">
                            <?php if ($row['judul']): ?>                                
                            <div class="card-body-1 mt-4">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" style="text-decoration: none; color: #333">
                                            <b><?= $row['judul'] ?></b></a>
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                            <?php endif ?>
                            <div>
                                <?php foreach ($main['contact'] as $contacts): ?>                                      
                                  <span style="background: #e6e6e6;padding: 5px 10px;display: block;border-bottom: 1px solid #cecece;border-radius: 2px;box-shadow: 0 0.5px 0.5px rgba(200,200,200,0.7);margin-bottom: 3px;"> 
                                    <?php if ($contacts['role'] != 0): ?>
                                        <?php if (!$contacts['image_null']): ?>
                                            <img src="<?= $contacts['img'] ?>" alt="<?= $contacts['title'] ?>" width="25px">
                                        <?php endif ?>
                                        <span><?= $contacts['title'] ?> : <a href="<?= $contacts['link'] ?>" title="<?= $contacts['title'] ?>" target="_blank"><?= $contacts['id'] ?></a></span>                                        
                                    <?php else: ?>
                                        <?php if (!$contacts['image_null']): ?>
                                            <img src="<?= $contacts['img'] ?>" alt="<?= $contacts['title'] ?>" width="25px">
                                        <?php endif ?>
                                        <span style="position: relative;bottom: 3px;margin: 0 5px;"><?= $contacts['title'] ?> : <span><?= $contacts['id'] ?></span></spa>
                                    <?php endif ?>                                    
                                  </span>
                                <?php endforeach ?>                            
                            </div>
                        </div>
                    <?php elseif($row['role'] == 3): ?>
                        <div class="p-1 color-primary" style="margin-bottom: 10px">             
                            <a href="<?= base_url('/') ?>" title="<?= $main['profile']['judul'] ?>">
                                <img src="<?= AWS_PATH.'image/'.$main['profile']['logo'] ?>" alt="logo" style="max-height:75px">
                            </a>
                        </div>

                    <?php elseif($row['role'] == 4): ?>
                        <div class="p-1 color-primary" style="margin-bottom: 10px">
                            <?php if ($row['judul']): ?>                                
                            <div class="card-body-1 mt-4">
                                <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                                    <?= $row['judul']?>
                              </h2>
                            </div>
                            <?php endif ?>
                            <div>
                                <?= $main['profile']['deskripsi'] ?>
                            </div>
                        </div>

                    <?php elseif($row['role'] == 5): ?>
                        <div class="p-1 color-primary" style="margin-bottom: 10px">
                            <?php foreach ($row['data'] as $item): ?>
                                <div style="position: relative;border-radius: 2px;overflow: hidden;margin-bottom: 10px;">
                                    <img src="<?= AWS_PATH.'image/'.$item['gambar'] ?>" alt="<?= $item['judul'] ?>" style="display: block;">
                                    <a href="<?= base_url('category/'.$item['slug']) ?>" title="<?= $item['judul'] ?>" style="position: absolute;bottom: 0;padding: 0;height: 100%;width: 100%;display: flex;background: rgba(0,0,0,0.2);">
                                        <span style="font-size: 15.5px;background: rgba(0,0,0,0.7);padding: 5px 10px;margin: 10px auto auto 10px;border-radius: 5px;color: #eee;"><?= $item['judul'] ?></span>
                                    </a>
                                </div>
                            <?php endforeach ?>
                        </div>    
                    <?php elseif($row['role'] == 7): ?>
                        <div class="p-1 color-primary" style="margin-bottom: 10px">
                            <?php if ($row['judul']): ?>                                
                            <div class="card-body-1 mt-4">
                                <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                                    <?= $row['judul'] ?>
                                </h2>
                            </div>
                            <?php endif ?>
                            <ul style="padding: 0;list-style: none;margin-top: 2px">  
                                <?php foreach ($row['data'] as $item ): ?>
                                <li style="display: flex;padding: 7px;border-bottom: 2px solid #efefef">
                                        <a href="<?= $item['link'] ?>" title="<?= $item['title'] ?>" class="color-primary">
                                          <span style="margin: auto 0;font-weight: 500;font-size: 16px;">
                                            <?= $item['title'] ?>
                                        </span>
                                    </a>
                                </li>
                                <?php endforeach ?>
                            </ul>
                        </div>

                    <?php elseif($row['role'] == 8): ?>
                        <div class="p-1 color-primary" style="margin-bottom: 10px">
                            <?php if ($row['judul']): ?>                                
                            <div class="card-body-1 mt-4">
                                <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                                    <?= $row['judul'] ?>                  
                                </h2>
                            </div>
                            <?php endif ?>
                            <ul style="padding: 0;list-style: none;margin-top: 2px"> 
                                <?php foreach ($main['menu'] as $key): ?>                                     
                                <?php if ($key['link'] != 'kategori'): ?>
                                <li style="display: flex;padding: 7px;border-bottom: 2px solid #efefef">
                                        <a href="<?= $key['link'] ?>" title="<?= $key['judul'] ?>" class="color-primary">
                                          <span style="margin: auto 0;font-weight: 500;font-size: 16px;">
                                            <?= $key['judul'] ?>
                                        </span>
                                    </a>
                                </li>
                                <?php endif ?>                                   
                                <?php endforeach ?>
                            </ul>
                        </div>                    
                    <?php elseif($row['role'] == 10): ?>
                       <div class="p-1 color-primary" style="margin-bottom: 10px">
                            <?php if ($row['judul']): ?>                                
                            <div class="card-body-1 mt-4">
                                <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                                    <?= $row['judul'] ?>
                                </h2>
                            </div>
                            <?php endif ?>
                            <ul style="padding: 0;list-style: none;margin-top: 2px">
                                <?php foreach ($row['data'] as $item): ?>
                                <li style="display: flex;padding: 7px;border-bottom: 2px solid #efefef">
                                        <a href="<?= base_url('link/'.$item['slug']) ?>" title="<?= $item['judul'] ?>"class="color-primary">
                                          <span style="margin: auto 0;font-weight: 500;font-size: 16px;">
                                           <?= $item['judul'] ?>
                                        </span>
                                    </a>
                                </li>
                                <?php endforeach ?>
                            </ul>
                        </div> 
                    <?php elseif($row['role'] == 11): ?>
                        <?php if (trim($main['profile']['map']) != ''): ?>                                
                            <div class="p-1 color-primary" style="margin-bottom: 10px">
                                <?php if ($row['judul']): ?>                                
                                <div class="card-body-1 mt-4">
                                    <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                                        <?= $row['judul'] ?>
                                    </h2>
                                </div>
                                <?php endif ?>
                                <div style="max-height: 300px; overflow: hidden;">
                                    <?= $main['profile']['map']; ?>                                
                                </div>
                            </div>
                        <?php endif ?>
                    <?php elseif($row['role'] == 12): ?>
                        <div class="p-1 color-primary" style="margin-bottom: 10px">
                            <?php if ($row['judul']): ?>                                
                            <div class="card-body-1 mt-4">
                               <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                                    <?= $row['judul'] ?>                    
                                </h2>
                            </div>
                            <?php endif ?>
                            <ul style="padding: 0;list-style: none;margin-top: 2px">                     
                                <?php foreach ($row['data'] as $item): ?>
                                <li style="display: flex;padding: 7px;border-bottom: 2px solid #efefef">
                                        <a href="<?= base_url('blog/'.$item['slug']) ?>" title="<?= $item['judul'] ?>" class="color-primary">
                                          <span style="margin: auto 0;font-weight: 500;font-size: 16px;">
                                            <?= $item['judul'] ?>
                                        </span>
                                    </a>
                                </li>                                    
                                <?php endforeach ?>
                            </ul>
                        </div>                    
                    <?php elseif($row['role'] == 13): ?>
                        <?php if ($main['profile']['tripadvisor'] != ''): ?>                                
                        <div class="p-1 color-primary" style="margin-bottom: 10px">
                            <?php if ($row['judul']): ?>                                
                            <div class="card-body-1 mt-4">
                                <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                                    <?= $row['judul']?>
                                </h2>
                            </div>
                            <?php endif ?>
                            <div>
                                <?= $main['profile']['tripadvisor']; ?>                                                
                            </div>
                        </div>
                        <?php endif ?>
                    <?php elseif($row['role'] == 14): ?>
                        <?php foreach ($row['data'] as $key): ?>
                            <?php if ($key['data'] != null): ?>
                                <div class="p-1 color-primary" style="margin-bottom: 10px">
                                    <div class="card-body-1 mt-4">
                                        <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                                            <?= $key['name'] ?>
                                        </h2>
                                    </div>
                                    <ul style="padding: 0;list-style: none;margin-top: 2px">
                                        <?php foreach ($key['data'] as $rows): ?>
                                        <li style="display: flex;padding: 7px;border-bottom: 2px solid #efefef">
                                                  <a href="<?= base_url('link/'.$rows['slug']) ?>" title="<?= $rows['judul'] ?>" class="color-primary">
                                                    <span style="margin: auto 0;font-weight: 500;font-size: 16px;">
                                                      <?= $rows['judul'] ?>
                                                  </span>
                                              </a>
                                          </li>
                                        <?php endforeach ?>
                                    </ul>
                                </div>
                            <?php endif ?>
                        <?php endforeach ?>                            
                    <?php elseif($row['role'] == 15): ?>
                        <?php if (!empty($row['data'])): ?>                                
                            <div class="p-1 color-primary" style="margin-bottom: 10px">
                                <?php if ($row['judul']): ?>                                
                                <div class="card-body-1 mt-4">
                                    <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                                        Patner                      
                                    </h2>
                                </div>
                                <?php endif ?>
                                <ul class="list-group-service list-group-flush mb-3 mr-4 pl-3">
                                    <?php foreach ($row['data'] as $rows): ?>
                                    <a href="<?= $rows['link'] ?>" title="<?= $rows['judul'] ?>" style="margin-bottom: 10px;background: #fff;padding: 0 11px;margin-right: 7px;border: 1px solid #e4e4e4;border-radius: 3px;display: inline-flex;">
                                        <?= $rows['judul'] ?>
                                    </a>                                        
                                    <?php endforeach ?>
                                </ul>
                            </div>
                        <?php endif ?>
                    <?php endif ?>
                <?php endforeach ?>                                        
            </div>