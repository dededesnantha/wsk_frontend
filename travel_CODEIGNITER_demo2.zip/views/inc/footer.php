        <!-- footer -->
        <footer class="container-fluid">
            <div class="container p-4">     
              
              <div class="row">
                <?php for ($i = 1; $i <= 3; $i++) { ?>
                  <div class="c-4 text-center">          
                    <?php foreach ($main['footer_kolom'.$i] as $row): ?>
                        <?php if ($row['template'] != null): ?>                                
                            <?php require_once($row['template']); ?>
                        <?php endif ?>    
                    <?php endforeach ?> 
                  </div>
                <?php } ?>       
              </div>
              <?php if (count($main['menu_footer']) != 0): ?>
                  
              <div class="row">
                <div class="c-12 sub-footer" style="padding: 2.5px 15px;color: #fff">
                    <?php foreach ($main['menu_footer'] as $row): ?>     
                       <a href="<?= $row['link'] ?> " title="<?= $row['judul']?>" style="font-family: 'Josefin Sans', sans-serif;color:#fff"><?= $row['judul']?></a>
                    <?php endforeach ?> 
                </div>
              </div>
              <?php endif ?>
            </div>      
          </footer>
        <!-- end footer -->

        <!-- copyrigth -->
        <div class="container-fluid text-center color-white p-3 sub-footer">
                <small>&copy;<?= date('Y') ?> All Rights Reserved.Powered by 
                  <span>
                    <a href="https://www.tayatha.com/" title="tayatha" target="_blank" class="color-white">tayatha</a>
                </span>
            </small>
        </div>
        <script type='text/javascript'>
              //<![CDATA[
              document.addEventListener('copy', function (e){
                  e.preventDefault();
                  e.clipboardData.setData("text/plain", ""+window.location.href+"");
              })
              //]]>
          </script>
        <!-- end copyrigth -->
    </div>
</body>

</html>