					<div class="bread-1 mt-4">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                            	<?php foreach ($breadcrumb as $row): ?>										
										<?php if ($row['url']): ?>												
											<li class="breadcrumb-item"><a href="<?= $row['url'] ?>"><?= $row['name'] ?></a></li>
										<?php else: ?>											
											<?php if (end($breadcrumb) == $row): ?>					
												<li class="breadcrumb-item active"><?= $row['name'] ?></li>
											<?php else: ?>
												<li class="breadcrumb-item"><?= $row['name'] ?></li>
											<?php endif ?>
										<?php endif ?>
									</span>									
								<?php endforeach ?>                              
                            </ol>
                        </nav>
                    </div>