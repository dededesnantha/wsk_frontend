<!DOCTYPE html>
<html lang="<?= $main['label']['en'] ?>">
<head>
  
  <?php if (trim($main['profile']['google_webmaster']) != ''): ?>
    <?= $main['profile']['google_webmaster']; ?>          
  <?php endif ?>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="<?= $main['color']['code_color'] ?>" />
  <meta name="apple-mobile-web-app-status-bar-style" content="<?= $main['color']['code_color'] ?>">
  <?php foreach ($seo as $value): ?>
    <?= $value ?> 
  <?php endforeach ?>
  <link rel="icon" type="image/png" href="<?= AWS_PATH.'image/'.$main['profile']['logo'] ?>">
  
  <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css?v=<?= $main['v'] ?>">
  <link rel="stylesheet" href="<?= base_url('asset/template2/css/nav.css?v='.$main['v']) ?>">
  <link rel="stylesheet" href="<?= base_url('asset/template2/css/grid.css?v='.$main['v']) ?>">
  <link rel="stylesheet" href="<?= base_url('asset/template2/font/style.css?v='.$main['v']) ?>">
  <link rel="stylesheet" href="<?= base_url('asset/template2/css/main.css?v='.$main['v']) ?>">
  <link rel="stylesheet" href="<?= base_url('asset/template2/slider.css?v='.$main['v']) ?>">
  <link rel="stylesheet" href="<?= base_url('asset/template2/style.css?v='.$main['v']) ?>">
 <style>.bg-primary{background: #11A0E9; }
  .color-primary{color: #11A0E9; }
  .btn:focus, .btn-focus {border-color: #11A0E9;}
  .btn:hover {background:#11A0E9; }
  .breadcrumb-item a {color: #11A0E9;}
  .pagination > li > a:hover, .pagination > li > span:hover {color: #11A0E9;}
  .pagination > li > a, .pagination > li > span {color: #11A0E9;}
  .pagination > .active > a, .pagination > .active > span, .pagination > .active > a:hover, .pagination > .active > span:hover, .pagination > .active > a:focus, .pagination > .active > span:focus {background-color: #11A0E9;border-color: #11A0E9;}
  .badge-primary {background-color: #11A0E9; }
  .tab>label {background: #11A0E9; }
  .tab-content {color: #11A0E9;border:2px solid #11A0E9; }
  .checkmark {border: 3px solid #11A0E9; }
  .checkbox input:checked ~ .checkmark {background-color: #11A0E9;   }
  li.nav ul.nav li.nav a {color: #3B4448;}
  @media screen and (max-width : 760px){.navigasi{border-bottom: 1px solid #11A0E9;}
  }
  .button-primary{border:2px solid #11A0E9; }
  .button-primary:hover{color:#11A0E9;border:2px solid #11A0E9; }
  .slider div {background-color: #11A0E9;border-bottom: 1.5px solid #11A0E9; }
  .review .block .rating .fill{color: #11A0E9;}
  .rating small{color: #11A0E9;}
  .rating a{
    color: #11A0E9;
  }
  footer {
    background: #2C2C2C;
    box-shadow: 0 -1px 1px rgba(0,0,0,0.3);
  }
  footer ul li{
    border-bottom-color: #fff  !important;
  
  }
  footer a,footer span,footer p{
    color: #fff  !important;
  }
  footer h3{
    color: #fff  !important;
  }
  .sub-footer a{
    color: #ffffff !important;
  }
  .sub-footer{background: #11A0E9;}

  /* link */
  li.nav ul.nav li.nav a:hover{
    color:#11A0E9;
  }
  a{
    color:#11A0E9;
  }
  /* Warna Utama */
  header.bg-primary{
    background: #11A0E9;
  }
  nav.bg-primary{
    background: #11A0E9;
  }
  ul.nav{
    background: #11A0E9;
  }

  /* Warna Konten */
  .slider div{
    background: #11A0E9
  }
  
  .card-1 > div > a > h2{
    background: #11A0E9
  }
  .card-2 > .card-2-content > div > a{
    background: #11A0E9;    
  }
  /* text button */
  .slider div span{
    color: #ffffff
  }
  .card-1 > div > a > h2{
    color: #ffffff
  }
  li.nav a{
    color: #ffffff
  }
  .card-2 > .card-2-content > div > a{
    color: #ffffff;
  }</style>
  <?php if ($main['component']['AMP']): ?>    
    <link rel="amphtml" href="<?= str_replace(base_url(''), base_url('').'/amp',current_url() ) ?>">  
  <?php endif ?>

  <?php if (trim($main['profile']['google_analytics']) != ''): ?>    
    <?= $main['profile']['google_analytics']; ?>  
  <?php endif ?>

  <?php if (trim($main['profile']['facebook_pixel']) != ''): ?>
    <?= $main['profile']['facebook_pixel']; ?>  
  <?php endif ?>

  <?php if (trim($main['profile']['tawk']) != ''): ?>
    <?= $main['profile']['tawk']; ?>  
  <?php endif ?>

  <?php if (!empty($optiomation)): ?>

   <script type="application/ld+json">    
    {
      "@context": "http://schema.org/",
      "@type": "WebSite",              
      "name": "<?= strtoupper(explode('.',str_replace('https://www.','', base_url('')))[0])  ?>",
      "url": "<?= base_url('') ?>",
      "potentialAction": {
      "@type": "SearchAction",
      "target": "<?= base_url('search') ?>?search={search_term_string}",
      "query-input": "required name=search_term_string"
    } 
  }  
</script>
<script type="application/ld+json">
  {
    "@context": "http://schema.org",
    "@type": "PostalAddress",
    "streetAddress": "<?= $main['profile']['alamat'] ?>"
  }
</script>
<?php endif ?>    
<script>
  function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }
</script>

<?php require_once('views/inc/schema.php') ?>
<?php require_once('views/inc/script.php') ?>
</head>

<body >

  <a href="<?= base_url('apps#/app/dashboard') ?>" style="height: 45px;width: 45px;background: #fff;border:4px solid #efefef;position: fixed;right: 5px;top:45%;border-radius: 100%;z-index: 999;box-shadow: 0px -1px 4px #9a9a9a"><i class="fa fa-gear" style="    margin: auto;display: table;font-size: 25px;position: relative;top: 5px;color: #807e7e;"></i></a>

  <div class="container">
    <div class="row">
      <div class="c-12">
        <div class="row">
          <div class="c-3 text-center">
            <a href="<?= base_url('') ?>" style="height: 100%;display: grid;">
              <img src="<?= AWS_PATH.'image/'.$main['profile']['logo'] ?>" alt="logo" style="max-height: 80px" class="p-1 m-auto">
            </a>
          </div>
          <!-- <div style="display: inline;padding: 21px;position: absolute;"> -->
            <div class="c-9">
              <div class="row">
                <div class="c-12" style="padding-top: 12px">
                  <div class="pull-left" style="font-family: 'Josefin Sans', sans-serif;">
                    <?php if ($main['phone']): ?>                    
                      <a href="telp:<?= $main['phone'] ?>">Call us : <i class="fas fa-car"></i> <?= $main['phone'] ?></a>
                    <?php endif ?>
                    <br>
                    <?php if ($main['email']): ?>                            
                      <a href="mailto:<?php $main['email'] ?>">Email : <?= $main['email'] ?></a>
                    <?php endif ?>
                  </div>
                  <div class="pull-right">
                    <?php foreach ($main['social_media'] as $social_media): ?>  
                      <a href="<?= $social_media['link'] ?>" title="<?= $social_media['title'] ?>">
                        <img src="<?= $social_media['img'] ?>" alt="<?= $social_media['title'] ?>" width="40px"></a>
                    <?php endforeach ?>
                  </div>
                </div>
              </div>
              <div style="padding: 25px 0" class="pull-right">
                <form method="get" action="<?= base_url('search')?>" class="row">
                  <div class="form-group">
                    <input type="search" name="search" class="form-control" placeholder="<?= $main['label']['Search'] ?>" aria-label="Search" value="<?= $this->input->get('search'); ?>">
                  </div>
                  <button type="submit" style="color:#ADA996;background: transparent;font-size: 20px;font-weight: 300;border: 2px solid;border-radius: 4px;height: 45px;padding: 9px 10px;margin: 0px 2px;padding-top: 5px;"><i class="icon icon-magnifier"></i></button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <header id="header" class="container-fluid bg-primary">    
        <nav class="container bg-primary">
          <div class="row" style="text-align: right;"> 
            <label for="show-menu" class="show-menu color-white" style="line-height:50px;top: 7px;"><i class="icon icon-menu" style="font-size: 26px"></i></label>  
            <input type="checkbox" id="show-menu" role="button">
            <div class="c-12 row navigasi"> 
              <ul id="menu" class="p-0 nav" style="width: 100%;height: auto;position: relative;margin: auto;">
                <?php foreach ($main['menu'] as $row): ?>  
                  <li class="nav">
                <?php if ($row['link'] == 'kategori'): ?>
                    <a href="#" title="<?= $row['judul'] ?>"> <?= $row['judul'] ?></a>
                <?php else: ?>
                    <a href="<?= $row['link'] ?>" title="<?= $row['judul'] ?>"><?= $row['judul'] ?></a>
                <?php endif ?>

                <?php if ($row['link'] == 'kategori'): ?>
                      <ul class="hidden nav">
                <?php foreach ($main['parent'][$row['id_parent']] as $key): ?>
                            <li class="nav">
                              <a href="<?= base_url('link').'/'.$key['slug'] ?>" title="<?= $key['judul'] ?>"><?= $key['judul'] ?></a></li>
               <?php endforeach ?>
                      </ul>
                 <?php endif ?> 
                  </li>
               <?php endforeach ?>
              </ul>
          </div>
            </div>
          </nav>
        </header>

    <main>
        <?php if ($main['wa'] != ''): ?>
            <a class="share_button" href="<?= $main['wa'] ?>" title="whatsapp" style="position: fixed;bottom: 25px;left: 20px;z-index: 99;" target="_blank">
              <img src="<?= base_url('img/wa2.png') ?>" alt="whatsapp" style="border-radius: 100%;width: 50px;box-shadow: 1px 1px 16px -2px rgba(0,0,0,.3);position:relative;z-index: 1;">
              <span class="s_tampil">WhatsApp</span>      
            </a>
        <?php endif ?>
    </main>
</body>
</html>
