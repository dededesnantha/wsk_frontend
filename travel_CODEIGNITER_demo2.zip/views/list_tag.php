		<!-- content -->
        <div class="container">
            <div class="row">
                <div class="c-8">
                    <?php require_once('views/component/alert.php') ?>
                    <?php require_once('views/inc/breadcrumb.php') ?>
                    <h1 class="card-title " style="margin-bottom: 30px;">                     
                        <?= $single['judul'] ?>                   
                    </h1>

                    <div class="w3-padding">
                        <p style="padding-left:15px">
                            <?= substr(strip_tags($list['data'][0]['deskripsi_blog']), 0,300) ?>
                            <?= substr(strip_tags($list['data'][0]['deskripsi_product']), 0,300) ?>..</p>
                    </div>
                    <div class="mb-4" style="background: #eee;box-shadow: 0 1px 2px rgba(200,200,200,0.3);border-radius: 2px;border-bottom: 1px solid #dadada;">
                            <?php require_once('views/component/ratting.php') ?>
                        
                        <h4 style="margin-bottom:7px;margin-left:10px;margin-top: 10px">Contents</h4>
                        <h5 style="margin:0;margin-left:10px;">
                            <a href="#judul">
                                <?= $single['judul'] ?>
                            </a>
                        </h5>
                        <ul style="margin:5px 0;list-style: decimal;">
                            <?php $i = 0; ?>
                            <?php foreach ($list['data'] as $row): ?>                            
                            <?php $i++; ?>
                            <li>
                                <a href="#<?= $row['slug_product'].$row['slug_blog'] ?>">
                                    <?= $row['judul_product'].$row['judul_blog'] ?>
                                </a>
                            </li>                        
                            <?php endforeach ?>
                        </ul>
                    </div>


                    <!-- list content -->
                    <div class="row">
                        <?php require_once('views/component/list_tag.php') ?>
                        <div class="col-12 text-center" style="display: flex;">
                            <?= $list['paging'] ?>
                        </div>
                    </div>
                    <div>
                        <?php require_once('views/component/give_review.php') ?>
                    </div>


                </div>                 
                <?php require_once('views/inc/sidebar.php') ?>
            </div>
        </div>