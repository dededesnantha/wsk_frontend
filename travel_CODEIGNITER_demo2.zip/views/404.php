		<!-- content -->
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12 pl-0 pr-0 pl-sm-3 pr-sm-3 mt-5">
                    <?php require_once('views/component/alert.php') ?>
                    <h1 class="card-title " style="margin-bottom: 30px;">
                        <?= $main['label']['Page Not Found!!'] ?>
                    </h1>                    
                </div>                 
                <?php require_once('views/inc/sidebar.php') ?>
            </div>
        </div>