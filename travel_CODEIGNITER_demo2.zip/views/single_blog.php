            <section class="container-fluid" style="height: 350px; background: <?= AWS_PATH.'image/'.$single['gambar'] ?>;filter: blur(5px);position: absolute;z-index: -2;background-size: cover ">
            </section>

            <div class="container">            
                <div class="row">
                    <div class="c-8" style="padding-top: 50px;">
                        <div class="container-fluid">            
                            <?php require_once('views/component/alert.php') ?>
                            <?php if ($single['gambar']): ?>                                
                                <img src="<?= AWS_PATH.'image/'.$single['gambar'] ?>" class="d-block w-100" alt="<?= $single['judul'] ?>" style="border-radius: 4px;box-shadow: 1px 1px 16px -2px rgba(0,0,0,.3);">
                            <?php endif ?>
                            <?php require_once('views/component/ratting.php') ?>
                            
                            <div class="price mt-4">
                                <div class="bg-white">
                                    <h1 class="card-title"><?= $single['judul'] ?></h1>                                
                                </div>
                            </div>
                            <?php require_once('views/inc/breadcrumb.php') ?>
                            <div class="p-1 bg-white" >
                                <?= $single['deskripsi'] ?>
                            </div>                            
                            <?php require_once('views/component/give_review.php') ?>
                            <hr style="margin: 25px 0 15px 0">
                            <?php require_once('views/component/tag.php') ?>
                            <hr style="margin: 25px 0 15px 0">
                            <?php require_once('views/component/share.php') ?>
                            <?php require_once('views/component/contact.php') ?>
                        </div>

                        <!-- booking -->
                        <div class="tab">
                            <input id="bookings" type="checkbox" name="tabs" class="acordion">
                            <label for="bookings" class="button-primary button-block bg-primary color-white"><?= $main['label']['Booking'] ?></label>
                            <div class="tab-content" style="border: none;">      
                                <form action="<?= base_url('booking') ?>" method="POST" enctype="multipart/form-data" >
                                  <div class="row">
                                    <div class="c-12 margin-bottom">
                                      <h2 class="font-secondary" style="font-weight: 500"><?= $main['label']['Select Tour'] ?> : </h2>
                                        <?php foreach ($product as $key): ?>
                                          <?php if ($key['data'] != null): ?>
                                            <div class="tab">
                                              <input id="<?= $key['slug'] ?>" type="checkbox" name="tabs" class="acordion" <?php if($key['slug'] == @$_SESSION['category']): echo 'checked' ;endif ?>>
                                              <label for="<?= $key['slug'] ?>" class="font-secondary"><?= $key['name'] ?></label>
                                              <div class="tab-content">
                                                <?php foreach ($key['data'] as $row): ?>
                                                <div>
                                                  <label class="checkbox" style="position: relative;padding: 2px 0 0 1.9em;line-height: 3;cursor: pointer;display: initial;font-weight: 400;font-size: 17px;">
                                                      <?= $row['judul']?>
                                                    <input type="checkbox" type="checkbox" value="<?= $row['judul'] ?>" name="tour[]" <?php if($row['judul'] == @$_SESSION['tour']): echo 'checked' ;endif ?> >
                                                    <span class="checkmark"></span>
                                                  </label>
                                                </div>
                                                <?php endforeach ?> 
                                              </div>
                                            </div>
                                          <?php endif ?>
                                        <?php endforeach ?> 
                                    </div>
                                    
                                    <div class="c-12 margin-bottom">
                                      <h2 class="font-secondary" style="font-weight: 500"><?= $main['label']['Or Custom Tour'] ?> : </h2>
                                      <div class="form-group" id="input_add" style="margin-top: 10px">
                                        <input class="form-control" id="custom" name="custom_tour[]" type="text" placeholder="Your Tour">
                                      </div>
                                      <button class="button-primary bg-primary color-white pull-right" id="add" type="button" style="font-family: 'Josefin Sans', sans-serif;"><?= $main['label']['Add Tour'] ?></button>  
                                    </div>
                                    <div class="c-12 margin-bottom">
                                      <h2 class="font-secondary" style="font-weight: 500"><?= $main['label']['Booking'] ?> : </h2>
                                        <div class="c-12">
                                            <div class="form-group">
                                                <div class="form-inline text-left">
                                                    <div class="mr-4">                                        
                                                        <input type="radio" name="initials" value="Mr." required> Mr.
                                                    </div>           
                                                    <div class="mr-4">
                                                        <input type="radio" name="initials" value="Mrs." required> Mrs.                                    
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                          <div class="form-group c-6">
                                            <input class="form-control" type="text" placeholder="<?= $main['label']['First Name'] ?>" required="" name="first_name">
                                          </div>
                                          <div class="form-group c-6">
                                            <input class="form-control" type="text" placeholder="<?= $main['label']['Last Name'] ?>" required="" name="last_name">
                                          </div>
                                        </div>
                                        
                                        <div class="form-group">
                                          <input class="form-control" type="email" placeholder="<?= $main['label']['Your Email'] ?>" required="" name="email">
                                        </div>
                                         <div class="form-group">
                                          <input class="form-control" type="text" placeholder="<?= $main['label']['Your Phone Number'] ?>" required="" name="phone">
                                        </div>
                                        
                                        <div class="row">
                                          <div class="form-group c-6" style="display: inherit;padding-right: 6px;">
                                            <input class="form-control" type="date" placeholder="Date" required="" name="tanggal" value="<?php if(isset($_SESSION['tanggal'])): echo $_SESSION['tanggal']; endif ?>" id="date">
                                            <label for="date" class="form-icon"><i class="icon icon-calendar"></i></label>                                  
                                          </div>
                                          <div class="form-group c-3">                    
                                            <select name="adult" required="" class="form-control">
                                              <option value="">-- <?= $main['label']['Adult'] ?> --</option>
                                              <?php for ($i = 1;$i < 21;$i++) {?>
                                              <option value="<?=$i?>" 
                                                <?php if (isset($_SESSION['adult']) && $_SESSION['adult'] == $i):echo "selected"; endif ?>>
                                                <?= $i ?></option>                      
                                              <?php } ?>
                                            </select>
                                          </div>
                                          <div class="form-group c-3">                      
                                            <select name="child" required="" class="form-control">
                                              <option value="">-- <?= $main['label']['Child'] ?> --</option>
                                              <?php for ($i = 0;$i < 11;$i++) {?>
                                              <option value="<?=$i?>" 
                                                <?php if (isset($_SESSION['child']) && $_SESSION['child'] == $i):echo "selected"; endif ?>>
                                                <?=$i?></option>                      
                                              <?php } ?>
                                            </select>
                                          </div>                  
                                        </div>    
                                        <div class="form-group">
                                          <textarea  cols="30" rows="5" class="form-control" type="text" placeholder="<?= $main['label']['Message'] ?>" name="deskripsi"></textarea>  
                                        </div>

                                        <div class="form-group">
                                          <h2 class="font-secondary" style="font-weight: 500"><?= $main['label']['Pick Up Information'] ?> : </h2>                  
                                        </div>
                                        <div class="row">
                                          <div class="form-group c-6">
                                            <input class="form-control" type="text" placeholder="<?= $main['label']['Pick Up Point'] ?>" name="pick_up_point">
                                          </div>
                                          <div class="form-group c-6">
                                            <input class="form-control" type="text" placeholder="<?= $main['label']['Your Hotel Stay'] ?>" name="hotel">
                                          </div>
                                          <div class="form-group c-6">
                                            <input class="form-control" type="text" placeholder="<?= $main['label']['Hotel Phone Number'] ?>" name="hotel_phone">
                                          </div>
                                          <div class="form-group c-6">
                                            <input class="form-control" type="text" placeholder="<?= $main['label']['Hotel Room Number'] ?>" name="hotel_room_number">
                                          </div>
                                        </div>
                                        <div class="form-group">
                                          <input class="form-control" type="text" placeholder="<?= $main['label']['Your Address / Hotel Address'] ?>" required="" name="address">
                                        </div>
                                        <?php if ($main['blok_booking']): ?>
                                        <div class="form-group">
                                          <div class="g-recaptcha" data-sitekey="<?=env('CAPCHA_KEY')?>"></div>                  
                                        </div>
                                        <?php endif ?>

                                        <div class="">
                                          <button class="button-primary bg-primary color-white pull-right" type="submit" style="padding: 5px 20px;font-family: 'Josefin Sans', sans-serif;"><?= $main['label']['Submit'] ?></button>
                                        </div>
                                      
                                    </div>
                                  </div>
                                </form>
                            </div>
                        </div>
                
                        <!-- end booking -->
                        <?php if ($main['component']['Comment']): ?>
                            <?php require_once('views/component/comment.php') ?>                            
                        <?php endif ?>
                        <?php require_once('views/component/related_blog.php') ?>
                        
                    </div>

                    <?php require_once('views/inc/sidebar.php') ?>
                </div>
            </div>



