            <section class="container-fluid" style="height: 350px; background: <?= AWS_PATH.'image/'.$single['gambar'] ?>;filter: blur(5px);position: absolute;z-index: -2;background-size: cover ">
            </section>
            <!--  -->

            <section class="container">
                    <div class="row">
                      <div class="c-8" style="padding-top: 50px;">
                        <?php require_once('views/component/alert.php') ?>               
                       <?php if ($single['gambar']): ?>
                        <img src="<?= AWS_PATH.'image/'.$single['gambar'] ?>" alt="<?= $single['judul'] ?>"style="border-radius: 4px;box-shadow: 1px 1px 16px -2px rgba(0,0,0,.3);" /> 
                        <?php endif ?>
                        <?php require_once('views/component/ratting.php') ?>
                        <div class="bg-white">
                          <h1 id="<?= str_replace(' ','_',$single['judul'])?>" style="margin: 5px 0px"><?= $single['judul'] ?></h1>
                      </div>
                      <?php require_once('views/inc/breadcrumb.php') ?>       
                      <div class="p-1 bg-white" id="<?= str_replace(' ','_',$single['judul'])?>">
                       <?= $single['deskripsi'] ?>
                   </div>
                   <hr style="margin: 25px 0 15px 0">      
                   <?php require_once('views/component/give_review.php') ?>     
                   <hr style="margin: 25px 0 15px 0">
                   <?php require_once('views/component/share.php') ?>         

                   <?php require_once('views/component/contact.php') ?>     

                    <?php if ($main['component']['Comment']): ?>
                        <?php require_once('views/component/comment.php') ?>                            
                    <?php endif ?>
                   <hr>
               </div>      
               <?php require_once('views/inc/sidebar.php') ?>     
           </div>
       </section>