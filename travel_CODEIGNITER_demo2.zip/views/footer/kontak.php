	<?php if ($row['judul'] != ''): ?>
		<h3 class="font-secondary color-white" style="font-size: 24.5px;font-weight: 500"><?= $row['judul']?></h3>
	<?php endif ?>		

<?php foreach ($main['contact'] as $contacts): ?>    
	
	<div style="text-align: left;padding-left: 24px;">
	<?php if ($contacts['role'] != 0): ?>
			<?php if (!$contacts['image_null']): ?>
				<a class="color-white" href="<?= $contacts['link']?>" title="<?= $contacts['title']?>" target="_blank">
					<img style="position: relative;top: 10px;" src="<?= $contacts['img'] ?>" alt="<?= $contacts['title'] ?>" width="30px">
				</a>
			<?php endif ?>
			<span class="color-white"><?= $contacts['title'] ?> :</span> <a class="color-white" href="<?= $contacts['link'] ?>" title="<?= $contacts['title'] ?>" target="_blank"><span><?= $contacts['id'] ?></span></a><br>

	<?php else: ?>

		<?php if (!$contacts['image_null']): ?>
			  	<img style="position: relative;top: 10px;" src="<?= $contacts['img'] ?>" alt="<?= $contacts['title'] ?>" width="30px">
		<?php endif ?>
			<span class="color-white"><?= $contacts['title'] ?> : <span ><?= $contacts['id'] ?></span></span><br>
	<?php endif ?>

	</div>
<?php endforeach ?>


		<div style="text-align: left;padding-left: 24px;">
			<p class="color-white text-left"><?= $main['label']['Address'] ?> : <?= $main['profile']['alamat'] ?> </span></p>
		</div>
		
<hr>