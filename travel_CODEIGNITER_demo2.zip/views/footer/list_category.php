		<?php if ($row['judul'] != ''): ?>	
	    	<h3 class="font-secondary color-white" style="font-size: 24.5px;font-weight: 500"><?= $row['judul'] ?></h3>
	    <?php endif ?>
	    <ul class="text-left" style="list-style: unset;color: #fff;line-height: 1.8;font-size: 15px;font-weight: 500;list-style: none;padding: 0">
	    	<?php foreach ($main['list_category'][$row['id_galeri_kategori']] as $list_categorys): ?>
	    	<li style="margin-bottom: 5px;border-bottom: 1px solid #fff;"><a href="<?= base_url('link').'/'.$list_categorys['slug'] ?>" title="<?= $list_categorys['judul'] ?>" class="color-white"><i class="icon icon-arrow-right"></i> <?= $list_categorys['judul'] ?></a></li>
	    	<?php endforeach ?>
	    </ul>        
	    <br>	