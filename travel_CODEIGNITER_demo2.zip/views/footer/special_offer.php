		<?php if ($row['judul'] != ''): ?>	
	            <h3 class="font-secondary color-white" style="font-size: 24.5px;font-weight: 500"><?= $row['judul'] ?></h3>
		<?php endif ?>
	    <ul class="text-left" style="list-style: unset;color: #fff;line-height: 1.8;font-size: 15px;font-weight: 500;list-style: none;padding: 0">
	    	<?php foreach ($main['spesial'] as $spesial): ?>
	    	<?php if ($spesial['page_judul'] == null): ?>			
	    	<li style="margin-bottom: 5px;border-bottom: 1px solid #fff;">
	    		<a href="<?= base_url('link').'/'.$spesial['product_slug'] ?>" title="<?= $spesial['product_judul'] ?>" class="color-white">
	    			<i class="icon icon-arrow-right">
	    			</i> <?= $spesial['product_judul'] ?></a></li>
	    	<?php else: ?>	
	    	<li style="margin-bottom: 5px;border-bottom: 1px solid #fff;"><a href="<?= base_url().'/'.$spesial['page_slug'] ?>" title="<?= $spesial['page_judul'] ?>" class="color-white"><i class="icon icon-arrow-right"></i> <?= $spesial['page_judul'] ?></a></li>
	    	<?php endif ?>
	    	<?php endforeach ?> 
	    </ul>
	    <br>