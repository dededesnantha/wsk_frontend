<div class="footer-img">
			<a href="<?= base_url() ?>" title="<?= $main['profile']['judul'] ?>">	
            	<img src="<?= AWS_PATH.'image/'.$main['profile']['logo'] ?>" alt="<?= $main['profile']['judul'] ?>" width="120px">
			</a>
        </div>