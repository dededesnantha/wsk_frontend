  <?php if ($row['judul'] != ''): ?>
    <h3 class="font-secondary color-white" style="font-size: 24.5px;font-weight: 500"><?= $row['judul'] ?></h3>
    <?php endif ?>
    <ul class="text-left" style="list-style: unset;color: #fff;line-height: 1.8;font-size: 15px;font-weight: 500;list-style: none;padding: 0">
         <?php foreach ($main['list_blog_footer'] as $list_blogs): ?>
        <li style="margin-bottom: 5px;border-bottom: 1px solid #fff;"><a href="<?= base_url('blog').'/'.$list_blogs['slug'] ?>" title="<?= $list_blogs['judul'] ?>" class="color-white"><i class="icon icon-arrow-right"></i> <?= $list_blogs['judul'] ?></a></li>
        <?php endforeach ?> 
    </ul>        
    <br>