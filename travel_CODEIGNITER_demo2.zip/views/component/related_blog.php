      <div class="row mt-4">
            <div class="col-lg-12 col-md-12 p-0 pl-md-2 pr-md-2">
                <h2 class="mb-4"><?= $single['judul_cat'] ?></h2>
            </div>    
            <?php foreach ($related as $row): ?>
            <div class="col-lg-12 col-md-6 col-sm-12 p-0 mb-3">
                <div class="blog-conten">
                    <div class="card">
                        <div class="row">
                              <div class="col-lg-5 col-md-12 p-0">
                                <a href="<?= base_url('blog/'.$row['slug']) ?>" title="<?= $row['judul'] ?>">
                                  <img src="<?=  AWS_PATH.'image/'.$row['gambar'] ?>" class="card-img-top" alt="<?= $row['judul'] ?>">
                                </a>
                              </div>
                              <div class="col-lg-7 col-md-12">
                                <div class="text-blog" style="padding: 10px 10px;">
                                    <h4 style="color: #2574a9; font-weight: 500">
                                        <?= $row['judul'] ?>
                                    </h4>
                                    <p class="card-text">
                                        <?= substr(strip_tags($row['deskripsi']), 0,150).'...' ?> 
                                    </p>
                                    <div class="text-right mb-2">                                    
                                        <a href="<?= base_url('blog/'.$row['slug']) ?>" title="<?= $row['judul'] ?>" type="button" class="btn btn-outline-primary">
                                          <?= $main['label']['Read More'] ?> >
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach ?>
        </div>