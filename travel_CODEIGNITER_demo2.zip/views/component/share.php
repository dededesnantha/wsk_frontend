
    <div class="pull-left" style="margin-bottom: 10px;">
      <span style="position: relative;bottom: 8px;font-weight: 700">Share To :</span>
      <!-- <?= $_REQUEST['tag']?> -->
      <a href="mailto:?Subject=<?= $single['judul'] ?>&amp;Body=<?= $single['judul'] ?> <?= $_SERVER['REQUEST_URI'] ?>" target="_blank"><img src="<?= base_url('img/icon') ?>/email.png"  width="32px" style="border-radius: 5px"></a>

      <a href="whatsapp://send?text=<?= $single['judul']?> <?= $_SERVER['REQUEST_URI'] ?>" target="_blank"><img src="<?= base_url('img/icon/wa.png')?>"  width="32px" style="border-radius: 5px"></a>
      <a href="https://lineit.line.me/share/ui?url= <?= $_SERVER['REQUEST_URI'] ?> " target="_blank"><img src="<?= base_url('img/icon') ?>/line.png"  width="32px" style="border-radius: 5px"></a>
      <a href="http://www.facebook.com/sharer.php?u= <?= $_SERVER['REQUEST_URI'] ?> " target="_blank"><img src="<?= base_url('img/icon') ?>/facebook.png"  width="32px" style="border-radius: 5px"></a>
      <a href="https://twitter.com/share?url= <?= $_SERVER['REQUEST_URI'] ?> &amp;text=<?= $single['judul'] ?>&amp;hashtags=<?= $single['judul'] ?>" target="_blank"><img src="<?= base_url('img/icon') ?>/twitter.png"  width="32px" style="border-radius: 5px"></a>
    </div>