	<div>                                  
	    <span>Tag :</span>
	    <?php foreach ($tag as $tags): ?>                                    
	        <a href="<?= base_url('tag').'/'.$tags['slug']  ?>" title="<?= $tags['judul'] ?>">
	            <small class="badge badge-primary"><?= $tags['judul'] ?></small>
	        </a>
	    <?php endforeach ?>                            
	</div>