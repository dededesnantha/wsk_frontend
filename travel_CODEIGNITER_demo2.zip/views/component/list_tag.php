    <?php $i=0; ?>
    <?php foreach ($list['data'] as $row): ?>
    <?php $i++; ?>            
    <div class="c-6  mb-3">
      <div class="blog-conten">
          <div class="card">            
              <div class="row">
                <?php if ($row['judul_product'] != ''): ?>
                    <div class="c-5">
                        <a href="<?= base_url('link/'.$row['slug_blog']) ?>" title="<?= $row['judul_product'] ?>">
                          <img src="<?=  AWS_PATH.'image/'.$row['gambar_product'] ?>" class="card-img-top" alt="<?= $row['judul_product'] ?>">
                        </a>
                    </div>
                    <div class="col-lg-7 col-md-12">
                      <div class="text-blog" style="padding: 10px 10px;">
                          <h4 id="<?= str_replace(' ','_',$row['slug_product']) ?>" style="color: #2574a9; font-weight: 500">
                            <?= $i.'. '.$row['judul_product'] ?>
                          </h4>
                          <p class="card-text">
                            <?= substr(strip_tags($row['deskripsi_product']), 0,150).'...' ?> 
                          </p>
                          <div class="text-right mb-2">                                    
                            <a href="<?= base_url('blog/'.$row['slug_product']) ?>" title="<?= $row['judul_product'] ?>" type="button" class="btn btn-outline-primary">
                              <?= $main['label']['Read More'] ?> >
                            </a>
                          </div>
                      </div>
                    </div>
                <?php elseif($row['judul_blog'] != ''): ?>
                    <div class="col-lg-5 col-md-12 p-0">
                        <a href="<?= base_url('blog/'.$row['slug_blog']) ?>" title="<?= $row['judul_blog'] ?>">
                          <img src="<?= base_url('gambar/400x350/'.$row['gambar_blog']) ?>" class="card-img-top" alt="<?= $row['judul_blog'] ?>">
                        </a>
                    </div>
                    <div class="col-lg-7 col-md-12">
                      <div class="text-blog" style="padding: 10px 10px;">
                          <h4 id="<?= str_replace(' ','_',$row['slug_blog']) ?>" style="color: #2574a9; font-weight: 500">
                            <?= $row['judul_blog'] ?>
                          </h4>
                          <p class="card-text">
                            <?= substr(strip_tags($row['deskripsi_blog']), 0,150).'...' ?> 
                          </p>
                          <div class="text-right mb-2">                                    
                            <a href="<?= base_url('blog/'.$row['slug_blog']) ?>" title="<?= $row['judul_blog'] ?>" type="button" class="btn btn-outline-primary">
                              <?= $main['label']['Read More'] ?> >
                            </a>
                          </div>
                      </div>
                    </div>
                <?php endif ?>
              </div>
          </div>
      </div>
    </div>
    <?php endforeach ?>      