        <?php foreach ($list['data'] as $row): ?>
          <div class="c-12" style="margin-bottom:20px">
              <div class="blog-conten">
                      <div class="row card-3">
                          <div class="c-5">
                            <a href="<?= base_url('blog/'.$row['slug']) ?>" title="<?= $row['judul'] ?>">
                              <img src="<?= AWS_PATH.'image/'.$row['gambar'] ?>" class="card-img-top" alt="<?= $row['judul'] ?>">
                            </a>
                          </div>
                          <div class="c-7">
                              <div class="text-blog" style="padding: 10px 10px;">
                                  <h3 class="font-secondary color-primary" style="color: #2574a9; font-weight: 500">
                                    <?= $row['judul'] ?>
                                  </h3>
                                  <p class="card-text">
                                    <?= substr(strip_tags($row['deskripsi']), 0,150).'...' ?> 
                                  </p>
                                  <div class="text-right" style="margin-bottom: 10px">                               
                                    <a href="<?= base_url('blog/'.$row['slug']) ?>" title="<?= $row['judul'] ?>" type="button" class="bg-primary color-white p-2">
                                      <?= $main['label']['Read More'] ?> >
                                    </a>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
          </div>
        <?php endforeach ?>      