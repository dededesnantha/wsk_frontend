<!-- full day tour -->
<div class="row">
    <div class="c-12">
        <h2 class="color-primary margin-bottom" style="margin-bottom: 20px"><?= $single['judul_cat'] ?></h2>
    </div> 

    <div class="row">

        <?php foreach ($related as $row): ?>
        <div class="c-4" style="margin-bottom:20px;height: 250px">
          <div class="card-1" style="height: 250px"> 
            <a href="<?= base_url('link').'/'.$row['slug'] ?>" title="<?= $row['judul'] ?>">
              <img src="<?=  AWS_PATH.'image/'.$row['gambar'] ?>" alt="<?= $row['judul'] ?>" style="height: auto !important">
            </a>
            <div>
              <a href="<?= base_url('link').'/'.$row['slug'] ?>" title="<?= $row['judul'] ?>">
                <h2 id="<?= str_replace(' ','_',$row['judul']) ?>" class="color-white font-secondary"><?= $row['judul']?></h2>
              </a>
              
            </div>
          </div>
        </div>                
        <?php endforeach ?>              

      </div>
</div>