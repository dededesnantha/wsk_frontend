     <?php foreach ($list['data'] as $row): ?> 
      <article class="c-6" style="margin-bottom:20px">
        <div class="card-2 text-center">
          <div class="card-2-image">
            <a href="<?= base_url('link/'.$row['slug']) ?>" title="<?= $row['judul'] ?>">
              <img src="<?=  AWS_PATH.'image/'.$row['gambar'] ?>" alt="<?= $row['judul'] ?>">
            </a>
          </div>

          <div style="border-left: 1px solid #d1d1d1;border-right: 1px solid #d1d1d1;border-top: 1px solid #d1d1d1;">          
            <a href="<?= base_url('link/'.$row['slug']) ?>" title="<?= $row['judul'] ?>">
              <h2 style="margin-top: 0;padding-top: 20px;margin-bottom: 0;" class="font-secondary color-primary"><?= $row['judul'] ?></h2>
            </a>
            <div class="card-2-content" style="display: grid;">
              <p>
                <?= substr(strip_tags($row['deskripsi']), 0,150) ?>..
              </p>
            </div>
            <?php if (round($row['price']) != 0): ?>
            <div class="card-2-content" style="padding:0 ;display: grid;">
              <div class="list-price">
                <small>Start From : </small>
                <span>
                   <?= $main['label']['Price Symbol'] ?> <?= number_format($row['price'],0,',','.'); ?>
                </span>
              </div>
            </div>
            <?php endif ?>
          </div>
          <div style="margin: 0;">
            <a href="<?= base_url('link/'.$row['slug']) ?>" title="<?= $row['judul'] ?>" class="card-2-button bg-primary color-white button-block p-2"><i class="icon icon-arrow-right"></i> <?= $main['label']['Read More'] ?></a>
          </div>
        </div>
      </article>
<?php endforeach ?>

