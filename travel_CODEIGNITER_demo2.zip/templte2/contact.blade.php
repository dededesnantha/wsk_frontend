@extends('front.layout')

@section('script')
<script src='https://www.google.com/recaptcha/api.js'></script>
@endsection
@section('content')

    <section class="container">
      <div class="row">
        <div class="c-8" style="padding-top: 50px">
          <div class="text-center">
            @include('front.component.alert')
            <h1 class="color-primary" style="font-family: 'Josefin Sans', sans-serif;">
              <?= $data['optiomation']['sitename'] ?>
            </h1>
            <div class="line color-primary"></div>
          </div>
          @include('front.component.breadcrumb')              
          <div class="row">                        
    
            @if(trim($main['profile_website']->map) != '')
                  <?= $main['profile_website']->map;  ?>
            @endif
            <div class="c-3">
              <a href="{{url('/')}}" title="{{$main['profile_website']->judul}}">
                <img src="{{url('image').'/'.$main['profile_website']->logo}}" alt="logo" width="120px">
              </a>
            </div>
            <div class="c-9">    

              <p>
                {{ $main['label']['Address'] }} : <span> {{$main['profile_website']->alamat}} </span>
              </p>
                                
              @foreach($main['contact'] as $row)
                @if($row['image_null'] != '')
                  <img src="{{ $row['img'] }}" alt="{{ $row['title'] }}" width="30px">
                @endif
                <span>{{$row['title']}} :</span><span>{{$row['id']}}</span>
                <br>
              @endforeach
              <hr>
              @foreach($main['social_media'] as $social_media)
                <a href="{{$social_media['link']}}" title="{{$social_media['title']}}">
                  <img src="{{$social_media['img']}}" alt="{{$social_media['title']}}" width="40px">
                </a>
              @endforeach
            </div>
          

            <div class="c-12 margin-bottom">
              <h2 class="font-secondary p-1" style="border-left: 5px solid #11A0E9;font-weight: 500">{{ $main['label']['Send Message'] }}</h2>
                        
              <form action="{{ url('contact') }}" method="POST" enctype="multipart/form-data" >
                {{ csrf_field() }}
                  <div class="form-group row">
                    <div class="c-6">
                      <input class="form-control" type="text" placeholder="{{ $main['label']['First Name'] }}" required="" name="name">
                    </div>
                    <div class="c-6">
                      <input class="form-control" type="text" placeholder="{{ $main['label']['Last Name'] }}" required="" name="last_name">
                    </div>
                  </div>
                  <div class="form-group">
                    <input class="form-control" type="text" placeholder="{{ $main['label']['Subject'] }}" required="" name="subject">
                  </div>
                  <div class="form-group">
                    <input class="form-control" type="email" placeholder="{{ $main['label']['Your Email'] }}" required="" name="email">
                  </div>
                  <div class="form-group">
                    <input class="form-control" type="text" placeholder="{{ $main['label']['Message'] }} " required="" name="message">
                  </div>
                  <div class="form-group">
                    <div class="g-recaptcha" data-sitekey="{{env('CAPCHA_KEY')}}"></div>
                  </div>
                  <div class="form-group">
                    <button class="button-primary bg-primary color-white" type="submit" style="padding: 5px 20px;font-family: 'Josefin Sans', sans-serif;">{{ $main['label']['Send Message'] }}</button>
                  </div>
              </form>
            </div>              
          </div>
        </div>        
        @include('front.inc.sidebar')
    </section>

@endsection