@extends('front.layout')

@section('script')
  @if($main['blok_booking'])
  <script src='https://www.google.com/recaptcha/api.js'></script>  
  @endif

  @include('front.component.script_ratting')  
  @include('front.component.script_review')  
  <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "Product",
      "@id": "{{str_replace(' ','_',$single->judul)}}",
      "name": "{{@$single->judul}}",
      "image": "{{asset('image/'.$single->gambar)}}",
      "gtin8": "{{str_replace(' ','_',$single->judul)}}",
      "description": "{{@$optiomation['description']}}",
      "aggregateRating": {      
        "@type": "AggregateRating",
        "reviewCount": "{{ $review_total }}",      
        "ratingValue": "{{ $review_ratting }}"    
      },
      "brand": "{{ $optiomation['sitename'] }}",    
      @if(round($single->price) != 0)
      "offers": {
        "@type":"Offer",    
        "priceCurrency": "{{$main['label']['Price Currency']}}",
        "price": "{{$single->price}}",
        "url": "{{ Request::fullUrl() }}",
        "availability": "http://schema.org/InStock"
      },
      @endif     
      "sku": "{{str_replace(' ','_',$single->judul)}}"
    }
  </script>
  <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "BreadcrumbList",  
      "itemListElement": [
        @foreach($breadcrumb  as $row)    
        {
          "@type": "ListItem", 
          "name": "{{ $row['name'] }}", 
          "position": "{{ $row['position'] }}", 
          "item": {
            "@type": "Thing", 
            "@id": "@if($row['url']){{ $row['link'] }}@else{{ Request::fullUrl() }}@endif"
          }
        }
        @if($row != end($breadcrumb)),@endif
        @endforeach
      ]
    }
  </script>
@endsection

@section('content')

    <section class="banner-post container-fluid" style="background: url('{{asset('gambar/378x350').'/'.$single->gambar}}');filter: blur(5px);position: absolute;z-index: -2;height: 300px">
    </section>
    <section class="container">
      <div class="row">
        <div class="c-8" style="padding-top: 50px;">
          @include('front.component.alert')          
          <div style="border-radius: 4px;box-shadow: 1px 1px 16px -2px rgba(0,0,0,.3);background: #fff">
              <div class="slider">
                <ul>
                  <li>
                    <img src="{{asset('gambar/730x374').'/'.$single->gambar}}" alt="{{$single->judul}}">
                  </li>
                  @foreach($slider as $slide)
                    @if($slide->gambar !=  $single->gambar)
                    <li>
                      <img src="{{asset('gambar/730x374').'/'.$slide->gambar}}" alt="{{$single->judul}}">
                    </li>  
                    @endif
                  @endforeach        
                </ul>
              </div>
          </div>                    
          @include('front.component.ratting')
          <div class="bg-white">          
            <h1 id="{{str_replace(' ','_',$single->judul)}}" style="margin: 5px 0px">{{@$single->judul}}</h1>    
            @if(round($single->price) != 0)
            <div class="single-price">
              <span>
                {{$main['label']['Price Symbol']}} <?= number_format($single->price,0,',','.'); ?>
              </span>
            </div>
            @endif
            
          </div>     

          @include('front.component.breadcrumb')            
          <div class="p-1 bg-white">
            <?= $single->deskripsi ?>
          </div>
  

          <div class="row" style="margin-top: 20px">
            @include('front.component.list_page')
          </div>
          
          @include('front.component.widget')

          @include('front.component.give_review',['param'=>'tour'])

          @include('front.component.tag')
          <hr style="margin: 25px 0 15px 0">
          @include('front.component.share')
          @include('front.component.contact')          
          <hr>
          <div>           
            <div class="text-center">
              <h2 class="color-primary" style="font-family: 'Josefin Sans', sans-serif;">
                {{ $main['label']['Booking'] }}
              </h2>
              <div class="color-primary line" style="margin-bottom: 25px"></div>          
              @if($main['component']['Single Page Booking'])
                @if($main['component']['Single Page Simple Booking'])
                  <form action="{{ url('single_booking') }}" method="POST" enctype="multipart/form-data" >
                    {{ csrf_field() }}
                    <input type="hidden" value="{{$single->slug_cat}}" name="category"> 

                    <div class="c-12 margin-bottom">
                      <div class="row">
                        <div class="form-group c-3">
                          <label for="tour">{{ $main['label']['Your Tour'] }} :</label>
                        </div>
                        <div class="form-group c-9">
                          <input class="form-control" type="text" placeholder="{{ $main['label']['Your Tour'] }}" value="{{$single->judul}}" readonly="true" name="tour">
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="form-group c-6" style="display: inherit;padding-right: 6px;">
                        <input class="form-control" type="date" placeholder="Date" required="" name="tanggal" value="{{ session('tanggal') }}" id="date">
                        <label for="date" class="form-icon"><i class="icon icon-calendar"></i></label>                                  
                      </div>
                      <div class="form-group c-3">                    
                        <select name="adult" required="" class="form-control">
                          <option value="">-- {{ $main['label']['Adult'] }} --</option>
                          @for($i = 1;$i < 21;$i++)
                          <option value="{{$i}}" <?php if (@session('adult') == $i):echo "selected"; endif ?>>{{$i}}</option>                      
                          @endfor
                        </select>
                      </div>
                      <div class="form-group c-3">                      
                        <select name="child" class="form-control">
                          <option value="">-- {{ $main['label']['Child'] }} --</option>
                          @for($i = 0;$i < 11;$i++)
                          <option value="{{$i}}" <?php if (@session('child') == $i):echo "selected"; endif ?>>{{$i}}</option>                      
                          @endfor
                        </select>
                      </div>                  
                    </div>                    
                    <div class="">
                      <button class="button-primary bg-primary color-white" type="submit" style="padding: 5px 20px;font-family: 'Josefin Sans', sans-serif;">{{ $main['label']['Send Booking'] }}</button>
                    </div>
                  </form>
                @else
                  <form action="{{ url('booking') }}" method="POST" enctype="multipart/form-data" >
                    {{ csrf_field() }}
                    <div class="row">                  
                      <div class="c-12 margin-bottom">
                        <div class="row">
                          <div class="form-group c-3">
                            <label for="tour">{{ $main['label']['Your Tour'] }} :</label>
                          </div>
                          <div class="form-group c-9">
                            <input class="form-control" type="text" placeholder="{{ $main['label']['Your Tour'] }}" value="{{$single->judul}}" readonly="true" name="tour[]">
                          </div>
                        </div>
                      </div>
                      <div class="c-12 margin-bottom">                      
                          <div class="text-left">
                            <span style="display: inline-flex;margin-right: 9px;">
                              <input type="radio" name="initials" value="Mr." class="form-control" required id="mr"> <label for="mr">Mr.</label>
                            </span>
                            <span style="display: inline-flex;margin-right: 9px;">
                              <input type="radio" name="initials" value="Mrs." class="form-control" required id="mrs"> <label for="mrs">Mrs.</label>
                            </span>
                          </div>
                          <div class="row">
                            <div class="form-group c-6">
                              <input class="form-control" type="text" placeholder="{{ $main['label']['First Name'] }}" required="" name="first_name">
                            </div>
                            <div class="form-group c-6">
                              <input class="form-control" type="text" placeholder="{{ $main['label']['Last Name'] }}" required="" name="last_name">
                            </div>
                          </div>
                          
                          <div class="form-group">
                            <input class="form-control" type="email" placeholder="{{ $main['label']['Your Email'] }}" required="" name="email">
                          </div>
                           <div class="form-group">
                            <input class="form-control" type="text" placeholder="{{ $main['label']['Your Phone Number'] }}" required="" name="phone">
                          </div>
                          
                          <div class="row">
                            <div class="form-group c-6" style="display: inherit;padding-right: 6px;">
                              <input class="form-control" type="date" placeholder="Date" required="" name="tanggal" value="{{ session('tanggal') }}" id="date">
                              <label for="date" class="form-icon"><i class="icon icon-calendar"></i></label>                                  
                            </div>
                            <div class="form-group c-3">                    
                              <select name="adult" required="" class="form-control">
                                <option value="">-- {{ $main['label']['Adult'] }} --</option>
                                @for($i = 1;$i < 21;$i++)
                                <option value="{{$i}}" <?php if (@session('adult') == $i):echo "selected"; endif ?>>{{$i}}</option>                      
                                @endfor
                              </select>
                            </div>
                            <div class="form-group c-3">                      
                              <select name="child" class="form-control">
                                <option value="">-- {{ $main['label']['Child'] }} --</option>
                                @for($i = 0;$i < 11;$i++)
                                <option value="{{$i}}" <?php if (@session('child') == $i):echo "selected"; endif ?>>{{$i}}</option>                      
                                @endfor
                              </select>
                            </div>                  
                          </div>    
                          <div class="form-group">
                            <textarea  cols="30" rows="5" class="form-control" type="text" placeholder="{{ $main['label']['Message'] }}" name="deskripsi"></textarea>  
                          </div>

                          <div class="form-group">
                            <h2 class="font-secondary" style="font-weight: 500">{{ $main['label']['Pick Up Information'] }} : </h2>                  
                          </div>
                          <div class="row">
                            <div class="form-group c-6">
                              <input class="form-control" type="text" placeholder="{{ $main['label']['Pick Up Point'] }}" name="pick_up_point">
                            </div>
                            <div class="form-group c-6">
                              <input class="form-control" type="text" placeholder="{{ $main['label']['Your Hotel Stay'] }}" name="hotel">
                            </div>
                            <div class="form-group c-6">
                              <input class="form-control" type="text" placeholder="{{ $main['label']['Hotel Phone Number'] }}" name="hotel_phone">
                            </div>
                            <div class="form-group c-6">
                              <input class="form-control" type="text" placeholder="{{ $main['label']['Hotel Room Number'] }}" name="hotel_room_number">
                            </div>
                          </div>
                          <div class="form-group">
                            <input class="form-control" type="text" placeholder="{{ $main['label']['Your Address / Hotel Address'] }}" required="" name="address">
                          </div>
                          @if($main['blok_booking'])
                          <div class="form-group">
                            <div class="g-recaptcha" data-sitekey="{{env('CAPCHA_KEY')}}"></div>                  
                          </div>
                          @endif

                          <div class="">
                            <button class="button-primary bg-primary color-white pull-right" type="submit" style="padding: 5px 20px;font-family: 'Josefin Sans', sans-serif;">{{ $main['label']['Submit'] }}</button>
                          </div>
                        
                      </div>
                    </div>
                  </form>
                @endif
              @endif

            </div>
          </div>
          <hr style="margin-bottom: 0px"> 
          @if($main['component']['Review'])
          <div class="c-12 c-md-12 c-sm-12 text-center">                    
              <br>
              <h2 class="color-primary" style="font-family: 'Josefin Sans', sans-serif;">
                  Review
              </h2>
              <div class="color-primary line" style="margin-bottom: 25px"></div>          
          </div>
          @include('front.component.review')
          @include('front.component.list_review',['foot'=>'show-more'])
          @endif

          @if($main['component']['Comment'])
            @include('front.component.comment',['param'=>'product'])
          @endif

          @include('front.component.related_product')
          
        </div>          
        @include('front.inc.sidebar')        
      </div>
    </section>
@endsection