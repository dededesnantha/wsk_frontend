@extends('front.layout')

@section('content')
    <section class="container">
      <div class="row">
        <div class="c-8">
          <h1>Error 404</h1>
          <h2>{{ $main['label']['Page Not Found!!'] }}</h2>
        </div>          
        @include('front.inc.sidebar')        
      </div>
    </section>
@endsection