@extends('front.layout')

@section('script')
@endsection
@section('content')
  <section class="container">
    <div class="row">
      <div class="c-8" style="padding-top: 50px">
        <div class="text-center">
          <h1 id="{{str_replace(' ','_',$optiomation['main_title'])}}" class="color-primary" style="font-family: 'Josefin Sans', sans-serif;">
            @if($main['profile_website']->judul == $optiomation['main_title'])            
              All Blog
            @else            
              Blog : {{$optiomation['main_title']}}                  
            @endif
          </h1>
          <div class="line color-primary"></div>
        </div>
        @include('front.component.breadcrumb')      
        <div class="row">                
          @include('front.component.list_blog')        
          <div class="col-12 m-auto">
             <?php echo $list->render(); ?>
          </div>

        </div>
      </div>      
      @include('front.inc.sidebar')
    </div>
  </section>
@endsection