@extends('front.layout')

@section('content')

    <section class="container">
      <div class="row">
        <div class="c-8" style="padding-top: 50px">
          <div class="text-center">
            <h1 id="{{str_replace(' ','_',@$seo->judul)}}" class="color-primary" style="font-family: 'Josefin Sans', sans-serif;">
              @if($main['profile_website']->judul == $optiomation['main_title'])
                All Tour
              @else
                {{@$optiomation['main_title']}}
              @endif
            </h1>
            <div class="line color-primary"></div>
          </div>
                      
          @include('front.component.breadcrumb')      
          <div class="row">
            @include('front.component.list_product')          
                                

            <div class="col-12 m-auto">
               <?php echo $list->render(); ?>
            </div>

          </div>
        </div>      
        @include('front.inc.sidebar')
      </div>
    </section>
 
@endsection