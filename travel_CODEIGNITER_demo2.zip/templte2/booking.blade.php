@extends('front.layout')

@section('script')  
  @if($main['blok_booking'])
  <script src='https://www.google.com/recaptcha/api.js'></script>
  @endif
  <script src="{{asset('front/template2')}}/jquery-3.1.1.min.js" type="text/javascript" ></script>
  <script>
    $(document).ready(function() {

    $('#add').click(function() {
    $('#input_add').append('<div class="form-group" id="input_add" style="margin-top: 10px"><input class="form-control" id="custom" name="custom_tour[]" type="text" placeholder="Your Tour" ></div>');
    });
    });
  </script>
@endsection
@section('content')
    <section class="container">
      <div class="row" >
        <div class="c-8" style="padding-top: 50px">
          <div class="text-center">
            @include('front.component.alert')          
            <h1 class="color-primary" style="font-family: 'Josefin Sans', sans-serif;">
              {{ $main['label']['Booking Your Tour'] }}
            </h1>
            <div class="line color-primary"></div>
          </div>
          
          @include('front.component.breadcrumb')
          <form action="{{ url('booking') }}" method="POST" enctype="multipart/form-data" >
            {{ csrf_field() }}
            <div class="row">
              <div class="c-12 margin-bottom">
                <h2 class="font-secondary" style="font-weight: 500">{{ $main['label']['Select Tour'] }} : </h2>
                  @foreach($product as $key)
                    @if($key['data'] != null)
                      <div class="tab">
                        <input id="{{$key['slug']}}" type="checkbox" name="tabs" class="acordion" <?php if($key['slug'] == session('category')): echo 'checked' ;endif ?>>
                        <label for="{{$key['slug']}}" class="font-secondary">{{$key['name']}}</label>
                        <div class="tab-content">
                          @foreach($key['data'] as $row)
                          <div>
                            <label class="checkbox" style="position: relative;padding: 2px 0 0 1.9em;line-height: 3;cursor: pointer;display: initial;font-weight: 400;font-size: 17px;">
                                {{$row->judul}}
                              <input type="checkbox" type="checkbox" value="{{$row->judul}}" name="tour[]"  <?php if($row->judul == session('tour')): echo 'checked' ;endif ?>>
                              <span class="checkmark"></span>
                            </label>
                          </div>
                          @endforeach
                        </div>
                      </div>
                    @endif
                  @endforeach
              </div>
              
              <div class="c-12 margin-bottom">
                <h2 class="font-secondary" style="font-weight: 500">{{ $main['label']['Or Custom Tour'] }} : </h2>
                <div class="form-group" id="input_add" style="margin-top: 10px">
                  <input class="form-control" id="custom" name="custom_tour[]" type="text" placeholder="Your Tour">
                </div>
                <button class="button-primary bg-primary color-white pull-right" id="add" type="button" style="font-family: 'Josefin Sans', sans-serif;">{{ $main['label']['Add Tour'] }}</button>  
              </div>
              <div class="c-12 margin-bottom">
                <h2 class="font-secondary" style="font-weight: 500">{{ $main['label']['Booking'] }} : </h2>
                
                  <div>                
                    <span style="display: inline-flex;margin-right: 9px;">
                      <input type="radio" name="initials" value="Mr." class="form-control" required id="mr"> <label for="mr">Mr.</label>
                    </span>
                    <span style="display: inline-flex;margin-right: 9px;">
                      <input type="radio" name="initials" value="Mrs." class="form-control" required id="mrs"> <label for="mrs">Mrs.</label>
                    </span>
                  </div>
                  <div class="row">
                    <div class="form-group c-6">
                      <input class="form-control" type="text" placeholder="{{ $main['label']['First Name'] }}" required="" name="first_name">
                    </div>
                    <div class="form-group c-6">
                      <input class="form-control" type="text" placeholder="{{ $main['label']['Last Name'] }}" required="" name="last_name">
                    </div>
                  </div>
                  
                  <div class="form-group">
                    <input class="form-control" type="email" placeholder="{{ $main['label']['Your Email'] }}" required="" name="email">
                  </div>
                   <div class="form-group">
                    <input class="form-control" type="text" placeholder="{{ $main['label']['Your Phone Number'] }}" required="" name="phone">
                  </div>
                  
                  <div class="row">
                    <div class="form-group c-6" style="display: inherit;padding-right: 6px;">
                      <input class="form-control" type="date" placeholder="Date" required="" name="tanggal" value="{{ session('tanggal') }}" id="date">
                      <label for="date" class="form-icon"><i class="icon icon-calendar"></i></label>                                  
                    </div>
                    <div class="form-group c-3">                    
                      <select name="adult" required="" class="form-control">
                        <option value="">-- {{ $main['label']['Adult'] }} --</option>
                        @for($i = 1;$i < 21;$i++)
                        <option value="{{$i}}" <?php if (@session('adult') == $i):echo "selected"; endif ?>>{{$i}}</option>                      
                        @endfor
                      </select>
                    </div>
                    <div class="form-group c-3">                      
                      <select name="child" class="form-control">
                        <option value="">-- {{ $main['label']['Child'] }} --</option>
                        @for($i = 0;$i < 11;$i++)
                        <option value="{{$i}}" <?php if (@session('child') == $i):echo "selected"; endif ?>>{{$i}}</option>                      
                        @endfor
                      </select>
                    </div>                  
                  </div>    
                  <div class="form-group">
                    <textarea  cols="30" rows="5" class="form-control" type="text" placeholder="{{ $main['label']['Message'] }}" name="deskripsi"></textarea>  
                  </div>

                  <div class="form-group">
                    <h2 class="font-secondary" style="font-weight: 500">{{ $main['label']['Pick Up Information'] }} : </h2>                  
                  </div>
                  <div class="row">
                    <div class="form-group c-6">
                      <input class="form-control" type="text" placeholder="{{ $main['label']['Pick Up Point'] }}" name="pick_up_point">
                    </div>
                    <div class="form-group c-6">
                      <input class="form-control" type="text" placeholder="{{ $main['label']['Your Hotel Stay'] }}" name="hotel">
                    </div>
                    <div class="form-group c-6">
                      <input class="form-control" type="text" placeholder="{{ $main['label']['Hotel Phone Number'] }}" name="hotel_phone">
                    </div>
                    <div class="form-group c-6">
                      <input class="form-control" type="text" placeholder="{{ $main['label']['Hotel Room Number'] }}" name="hotel_room_number">
                    </div>
                  </div>
                  <div class="form-group">
                    <input class="form-control" type="text" placeholder="{{ $main['label']['Your Address / Hotel Address'] }}" required="" name="address">
                  </div>
                  @if($main['blok_booking'])
                  <div class="form-group">
                    <div class="g-recaptcha" data-sitekey="{{env('CAPCHA_KEY')}}"></div>                  
                  </div>
                  @endif

                  <div class="">
                    <button class="button-primary bg-primary color-white pull-right" type="submit" style="padding: 5px 20px;font-family: 'Josefin Sans', sans-serif;">{{ $main['label']['Submit'] }}</button>
                  </div>
                
              </div>
            </div>
          </form>
        </div>
        @include('front.inc.sidebar')
      </div>
    </section>

@endsection