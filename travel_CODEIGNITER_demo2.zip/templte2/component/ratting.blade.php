        <div style="border-radius: 2px;margin-bottom: 15px;background: #f5f5f5;border-bottom: 2px solid #ececec;padding: 3px 10px;" class="bg-white">          
          <span class="p-1"></span>
          @if(@$single->view)
          <span style="font-family: 'Josefin Sans', sans-serif;"><i class="icon icon-eye" style="position: relative;top: 1px;font-size: 15px;"></i> {{ @$single->view }} View</span>          
          @endif

          <div class="pull-right">
            <span style="font-family: 'Josefin Sans', sans-serif;padding-right: 5px">{{ $review_total }} </span><span>Reviews</span>
            /
            <span>{{ $review_ratting }}</span> 
            @for ($i=0; $i < (int)$review_ratting; $i++)
                <i class="icon icon-star" style="font-size: 16px;font-weight: 900;color: #e6e601;"></i>
            @endfor          
            @for ($i=0;$i < (5 - (int)$review_ratting);$i++)
              <i class="icon icon-star" style="font-size: 16px;font-weight: 900;"></i>
            @endfor                  
          </div>
        </div>