        <?php $i = 0; ?>
        @foreach($list as $row)
            <?php $i++; ?>
            @if($row->judul_product == '')
              
              <div class="c-12" style="margin-bottom:20px">
                <div class="row card-3">
                  <div class="c-5">
                    <a href="{{ url('blog/'.$row->slug_blog) }}" title="{{$row->judul_blog}}">
                      <img src="{{ url('gambar/417x348/'.$row->gambar_blog) }}" alt="{{$row->judul_blog}}">
                    </a>
                  </div>
                  <div class="c-7">
                    <a href="{{url('blog/'.$row->slug_blog)}}" title="{{$row->judul_blog}}">
                      <h2 class="font-secondary color-primary" id="{{$row->slug_blog}}">{{ $i.'. '.$row->judul_blog }}</h2>
                    </a>
                    <p>
                      {{ substr(strip_tags($row->deskripsi_blog), 0,150)}}..
                    </p>
                    <div class="pull-right" style="margin-bottom: 10px">
                      <a href="{{url('blog/'.$row->slug_blog)}}" title="{{$row->judul_blog}}" class="bg-primary color-white p-2"><i class="icon icon-arrow-right"></i> {{ $main['label']['Read More'] }}</a>
                    </div>
                  </div>
                </div>
              </div>
              
            @elseif($row->judul_blog == '')
              <div class="c-12" style="margin-bottom:20px">
                <div class="row card-3">
                  <div class="c-5">
                    <a href="{{ url('link/'.$row->slug_product) }}" title="{{$row->judul_product}}">
                      <img src="{{ url('gambar/417x348/'.$row->gambar_product) }}" alt="{{$row->judul_product}}">
                    </a>
                  </div>
                  <div class="c-7">
                    <a href="{{url('link/'.$row->slug_product)}}" title="{{$row->judul_product}}">
                      <h2 class="font-secondary color-primary" id="{{$row->slug_product}}">{{ $i.'. '.$row->judul_product }}</h2>
                    </a>
                    <p>
                      {{ substr(strip_tags($row->deskripsi_product), 0,150)}}..
                    </p>
                    <div class="pull-right" style="margin-bottom: 10px">
                      <a href="{{url('link/'.$row->slug_product)}}" title="{{$row->judul_product}}" class="bg-primary color-white p-2"><i class="icon icon-arrow-right"></i> {{ $main['label']['Read More'] }}</a>
                    </div>
                  </div>
                </div>
              </div>
              
            @endif
          @endforeach