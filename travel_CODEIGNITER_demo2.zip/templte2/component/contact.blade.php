	<div class="pull-right" style="margin-bottom: 10px;">
		<strong style="font-family: 'Josefin Sans', sans-serif;position: relative;top: -10px;padding-right: 5px;">Contact :</strong>
		@foreach($main['contact'] as $row)
          @if($row['role'] != 0)		  
		    <span>
		    	<a href="{{$row['link']}}" title="{{$row['title']}}" target="_blank">
		    		<img src="{{$row['img']}}" alt="{{$row['title']}}" style="width: 35px;border-radius: 5px">
		    	</a>
		    </span>
		  @endif
		@endforeach
	</div>