<style>.bg-primary{background: #11A0E9; }
  .color-primary{color: #11A0E9; }
  .btn:focus, .btn-focus {border-color: #11A0E9;}
  .btn:hover {background:#11A0E9; }
  .breadcrumb-item a {color: #11A0E9;}
  .pagination > li > a:hover, .pagination > li > span:hover {color: #11A0E9;}
  .pagination > li > a, .pagination > li > span {color: #11A0E9;}
  .pagination > .active > a, .pagination > .active > span, .pagination > .active > a:hover, .pagination > .active > span:hover, .pagination > .active > a:focus, .pagination > .active > span:focus {background-color: #11A0E9;border-color: #11A0E9;}
  .badge-primary {background-color: #11A0E9; }
  .tab>label {background: #11A0E9; }
  .tab-content {color: #11A0E9;border:2px solid #11A0E9; }
  .checkmark {border: 3px solid #11A0E9; }
  .checkbox input:checked ~ .checkmark {background-color: #11A0E9;   }
  li.nav ul.nav li.nav a {color: #3B4448;}
  @media screen and (max-width : 760px){.navigasi{border-bottom: 1px solid #11A0E9;}
  }
  .button-primary{border:2px solid #11A0E9; }
  .button-primary:hover{color:#11A0E9;border:2px solid #11A0E9; }
  .slider div {background-color: #11A0E9;border-bottom: 1.5px solid #11A0E9; }
  .review .block .rating .fill{color: #11A0E9;}
  .rating small{color: #11A0E9;}
  .rating a{
    color: #11A0E9;
  }
  footer {
    background: #2C2C2C;
    box-shadow: 0 -1px 1px rgba(0,0,0,0.3);
  }
  footer ul li{
    border-bottom-color: #fff  !important;
  
  }
  footer a,footer span,footer p{
    color: #fff  !important;
  }
  footer h3{
    color: #fff  !important;
  }
  .sub-footer a{
    color: #ffffff !important;
  }
  .sub-footer{background: #11A0E9;}

  /* link */
  li.nav ul.nav li.nav a:hover{
    color:#11A0E9;
  }
  a{
    color:#11A0E9;
  }
  /* Warna Utama */
  header.bg-primary{
    background: #11A0E9;
  }
  nav.bg-primary{
    background: #11A0E9;
  }
  ul.nav{
    background: #11A0E9;
  }

  /* Warna Konten */
  .slider div{
    background: #11A0E9
  }
  
  .card-1 > div > a > h2{
    background: #11A0E9
  }
  .card-2 > .card-2-content > div > a{
    background: #11A0E9;    
  }
  /* text button */
  .slider div span{
    color: #ffffff
  }
  .card-1 > div > a > h2{
    color: #ffffff
  }
  li.nav a{
    color: #ffffff
  }
  .card-2 > .card-2-content > div > a{
    color: #ffffff;
  }</style>