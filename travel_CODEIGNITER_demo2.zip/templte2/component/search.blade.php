          @foreach($list as $row)                        
            <div class="c-6" style="margin-bottom:20px;height: 250px">
              <div class="card-1" style="height: 250px"> 
                <a href="{{url('link/'.$row->slug)}}" title="{{$row->judul}}">
                  <img src="{{asset('gambar/350x500').'/'.$row->gambar}}" alt="{{$row->judul}}">
                </a>
                <div>
                  <a href="{{url('link/'.$row->slug)}}" title="{{$row->judul}}">
                    <h2 id="{{str_replace(' ','_',$row->judul)}}" class="color-white font-secondary">{{$row->judul}}</h2>
                  </a>
                  
                </div>
              </div>
            </div> 
          @endforeach