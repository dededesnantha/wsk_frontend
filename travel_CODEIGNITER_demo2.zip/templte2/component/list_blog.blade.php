        @foreach($list as $row)
          <div class="c-12" style="margin-bottom:20px">
            <div class="row card-3">
              <div class="c-5">
                <a href="{{url('blog/'.$row->slug)}}" title="{{$row->judul}}" >
                  <img src="{{url('gambar/417x348/'.$row->gambar)}}" alt="{{$row->judul}}" >
                </a>
              </div>
              <div class="c-7">
                <div class="text-blog" style="padding: 10px 10px;">
                <h2 id="{{str_replace(' ','_',$row->judul)}}" class="font-secondary color-primary">{{$row->judul}}</h2>
                <p>
                  <?= substr(strip_tags($row->deskripsi), 0,150) ?>                      
                </p>
                <div class="pull-right" style="margin-bottom: 10px">
                  <a href="{{url('blog/'.$row->slug)}}" title="{{$row->judul}}" class="bg-primary color-white p-2"><i class="icon icon-arrow-right"></i> {{ $main['label']['Read More'] }}</a>
                </div>
              </div>
              </div>
            </div>
          </div>
        @endforeach