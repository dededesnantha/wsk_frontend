<div class="color-primary bg-white" style="margin:20px 0;font-size: 12.5px;padding: 3px 10px;background: #f7f7f7;border: 1px solid #eee;border-radius: 2px;box-shadow: 0px 1px 2px rgba(0,0,0,0.2);letter-spacing: 1.1px;">
    
    @foreach($breadcrumb  as $row)
        <span>        
            @if($row['url'])                             
                <a href="{{$row['link']}}" title="{{ $row['name'] }}">
                    <span class="font-secondary color-primary">{{ $row['name'] }}</span>                
                </a>
            @else        
                <span class="font-secondary" style="color:#272727">{{ $row['name'] }}</span>            
            @endif
            @if($row['next']) 
                <i class="icon icon-arrow-right" style="font-size: 9px"></i>
            @endif
        </span>
    @endforeach            
</div>