          <div class="list-comment" style="margin-top: 80px">
            @if(!empty($comment))
            <h2 class="color-primary">Comment : </h2>
            @endif
            @foreach($comment as $row1)
            <div class="comment comment-parent ">
              <h3 class="title color-primary">{{ $row1['name'] }}</h3>
              @if($row1['user'] )
              <span class="email">
                ({{ $row1['email'] }})
              </span>
              @endif
              @if( !$row1['user'] )
                <span class="label color-primary">Admin Reply</span>
              @endif
              <div class="date">
                {{ $row1['created_at'] }}
              </div>
              <div class="message">
                {{ $row1['message'] }}
              </div>            
              

            </div>
              @foreach($row1['child'] as $row2)
              <div class="comment comment-child" style="">
               <h3 class="title color-primary">{{ $row2['name'] }}</h3>
                @if($row2['user'])
                <span class="email">              
                  ({{ $row1['email'] }})                  
                </span>
                @endif
                @if( !$row2['user'] )
                  <span class="label color-primary">Admin Reply</span>
                @endif
                <div class="date">
                  {{ $row2['created_at'] }}
                </div>
                <div class="message">
                  {{ $row2['message'] }}
                </div>
              </div>
              @endforeach
            @endforeach

          </div>

          <div style="background: #fff;padding: 10px 20px;border-radius: 3px;">
            <form action="{{url('comment/'.$param.'/'.$single->slug)}}" method="post" accept-charset="utf-8">
              {{ csrf_field() }}            
              <h2 class="color-primary" style="margin-bottom: 5px;margin-top: 11px;">Send Comment</h2>
              <div class="row">
                <div class="form-group c-6">
                  <label>Name : </label>
                  <input type="text" name="name" class="form-control" required="">
                </div>
                <div class="form-group c-6">
                  <label>Email : </label>
                  <input type="email" name="email" class="form-control" required="">
                </div>
              </div>
              <div class="form-group">
                <label>Message : </label>            
                <textarea name="message" class="form-control" required=""></textarea>
              </div>
              <div class="form-group text-right">
                <button type="submit" class="button-primary bg-primary color-white" style="border-width: 2px;"> Send Comment </button>
              </div>
            </form>
          </div>