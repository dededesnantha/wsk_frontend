    <div class="pull-left" style="margin-bottom: 10px;">
      <span style="position: relative;bottom: 8px;font-weight: 700">Share To :</span>
      <a href="mailto:?Subject={{$single->judul}}&amp;Body={{$single->judul}} {{Request::fullUrl()}}" target="_blank"><img src="{{asset('img/icon')}}/email.png"  width="32px" style="border-radius: 5px"></a>
      <a href="whatsapp://send?text={{$single->judul}} {{Request::fullUrl()}}" target="_blank"><img src="{{asset('img/icon')}}/wa.png"  width="32px" style="border-radius: 5px"></a>
      <a href="https://lineit.line.me/share/ui?url={{Request::fullUrl()}}" target="_blank"><img src="{{asset('img/icon')}}/line.png"  width="32px" style="border-radius: 5px"></a>
      <a href="http://www.facebook.com/sharer.php?u={{Request::fullUrl()}}" target="_blank"><img src="{{asset('img/icon')}}/facebook.png"  width="32px" style="border-radius: 5px"></a>
      <a href="https://twitter.com/share?url={{Request::fullUrl()}}&amp;text={{$single->judul}}&amp;hashtags={{$single->judul}}" target="_blank"><img src="{{asset('img/icon')}}/twitter.png"  width="32px" style="border-radius: 5px"></a>
    </div>