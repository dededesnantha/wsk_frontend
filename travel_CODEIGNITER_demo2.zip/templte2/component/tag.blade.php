    <div>
	    <strong style="font-family: 'Josefin Sans', sans-serif;">Tag :</strong>            
	    @foreach($tag as $tags)
	     <a href="{{url('tag').'/'.$tags->slug}}" title="{{$tags->judul}}"><small class="bg-primary color-white " style="padding:2.5px 6px">{{$tags->judul}}</small></a>              
	    @endforeach
	</div>