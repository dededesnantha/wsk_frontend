            @foreach($list as $row)
              <div class="c-6 card-4" style="margin-bottom:20px;">
                <img src="{{url('galeri/545x350/'.$row->gambar)}}" alt="{{$row->judul}}">               
              </div>
            @endforeach