    <div>
      <div class="row">
        <div class="c-12">          
          <h1 class=" color-primary margin-bottom" style="margin-bottom: 20px">{{$single->judul_cat}}</h1>
        </div>
      </div>
      <div class="row">

        @foreach($related as $row)
        <div class="c-4" style="margin-bottom:20px;height: 250px">
          <div class="card-1" style="height: 250px"> 
            <a href="{{url('link').'/'.$row->slug}}" title="{{$row->judul}}">
              <img src="{{asset('gambar/400x500').'/'.$row->gambar}}" alt="{{$row->judul}}" style="height: auto !important">
            </a>
            <div>
              <a href="{{url('link').'/'.$row->slug}}" title="{{$row->judul}}">
                <h2 id="{{str_replace(' ','_',$row->judul)}}" class="color-white font-secondary">{{$row->judul}}</h2>
              </a>
              
            </div>
          </div>
        </div>                
        @endforeach              

      </div>
    </div>