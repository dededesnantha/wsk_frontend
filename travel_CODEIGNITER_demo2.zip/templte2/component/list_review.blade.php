@if (count($web_review) != 0)        
<section class="review s-review">
    <div class="text-left">                    
        <h3 class="color title">Review</h3>                                
    </div>
    @foreach ($web_review as $item)            
        <div class="c-12">
            <div class="block">                                                                            
                <div>                                                            
                    <h3>{{$item->subject}}</h3>
                    <div class="rating">
                        @for ($i = 0; $i < (int)$item->count; $i++)
                            <i class="icon-round fill"></i>
                        @endfor
                        
                        @for ($i = 0; $i < (5- (int)$item->count); $i++)
                            <i class="icon-round"></i>
                        @endfor

                        <small class="color-primary"><i class="icon icon-user "></i> {{$item->name}}</small>
                    </div>                       
                    <div class="date">
                        <small content="{{$item->created_at}}"><i class="icon icon-user"></i> {{$item->filter_created_at}}</small>                               
                    </div>
                    <p>
                        {{$item->message}}
                    </p>
                </div>
            </div>                        
        </div> 
    @endforeach                
    <div class="c-12 text-center">
        @if ($foot == 'paging')
            <?php echo $web_review->render(); ?>    
        @elseif ($foot == 'show-more')                        
            <a href="{{url('review.html')}}" title="review" class="button-primary bg-primary color-white" style="padding: 10px 20px;font-family: 'Josefin Sans', sans-serif;"> Show More</a>
        @endif 
    </div>                      
</section>
@endif
