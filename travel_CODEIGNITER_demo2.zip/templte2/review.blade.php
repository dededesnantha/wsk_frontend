@extends('front.layout')

@section('script')
    <script src='https://www.google.com/recaptcha/api.js'></script>  
    @include('front.component.script_ratting')  
    @include('front.component.script_review')  
@endsection
@section('content')

  <section class="container">
    <div class="row">
      <div class="c-8" style="padding-top: 50px">
        @include('front.component.alert')        
        @include('front.component.breadcrumb')                      
        <div class="text-center">
          <h1 class="color-primary" style="font-family: 'Josefin Sans', sans-serif;">
              Review
          </h1>
          <div class="line color-primary"></div>
        </div>

        <div class="row">                
            @include('front.component.review')
            @include('front.component.list_review',['foot'=>'paging'])
        </div>
      </div>

      @include('front.inc.sidebar')
    </div>
  </section>

@endsection