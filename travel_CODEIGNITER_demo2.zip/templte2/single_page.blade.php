@extends('front.layout')

@section('script')
  @include('front.component.script_ratting')  
  <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "NewsArticle",
      "@id" : "{{str_replace(' ','_',$single->judul)}}",
      "datePublished": "{{$single->detail_created_at}}",
      "dateModified": "{{$single->detail_updated_at}}",         
      "headline": "{{@$single->judul}}",
      "image": "{{asset('image/'.$single->gambar)}}",      
      "articleBody": "{{@$optiomation['description']}}",
      "aggregateRating": {      
        "@type": "AggregateRating",
        "reviewCount": "{{ $review_total }}",      
        "ratingValue": "{{ $review_ratting }}"    
      },    
      "author": {
        "@type":"Thing",    
        "name": "{{ $optiomation['sitename'] }}"      
      },
      "publisher": {
        "@type":"Organization",
        "name": "{{ $optiomation['sitename'] }}",      
        "logo":  {
            "@type": "ImageObject",
            "name": "myOrganizationLogo",          
            "url": "{{asset('image').'/'.$main['profile_website']->logo}}"
        }
      },
      "mainEntityOfPage": {
       "@type": "WebPage",
       "@id": "{{ Request::fullUrl() }}"
      }
    }
  </script>
  <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "BreadcrumbList",  
      "itemListElement": [
        @foreach($breadcrumb  as $row)    
        {
          "@type": "ListItem", 
          "name": "{{ $row['name'] }}", 
          "position": "{{ $row['position'] }}", 
          "item": {
            "@type": "Thing", 
            "@id": "@if($row['url']){{ $row['link'] }}@else{{ Request::fullUrl() }}@endif"
          }
        }
        @if($row != end($breadcrumb)),@endif
        @endforeach
      ]
    }
  </script>
@endsection

@section('content')
  <section class="container-fluid" style="height: 350px;background: url('{{asset('gambar/350x350/'.$single->gambar)}}');filter: blur(5px);position: absolute;z-index: -2;background-size: cover ">
  </section>
  <section class="container">
    <div class="row">
      <div class="c-8" style="padding-top: 50px;">
        @include('front.component.alert')              
        @if(@$single->gambar != '')
          <img src="{{asset('image/'.$single->gambar)}}" alt="{{@$single->judul}}"style="border-radius: 4px;box-shadow: 1px 1px 16px -2px rgba(0,0,0,.3);" /> 
        @endif
        @include('front.component.ratting')           
        <div class="bg-white">          
          <h1 id="{{str_replace(' ','_',$single->judul)}}" style="margin: 5px 0px">{{@$single->judul}}</h1>
        </div>
        @include('front.component.breadcrumb')        
        <div class="p-1 bg-white" id="{{str_replace(' ','_',$single->judul)}}">
         <?= @$single->deskripsi ?>
        </div>
        <hr style="margin: 25px 0 15px 0">      
        @include('front.component.give_review',['param'=>'page'])      
        <hr style="margin: 25px 0 15px 0">
        @include('front.component.share')                  
        
        @include('front.component.contact')      

        @if($main['component']['Comment'])        
          @include('front.component.comment',['param'=>'page'])
        @endif
        <hr>
      </div>      
      @include('front.inc.sidebar')      
    </div>
  </section>
@endsection