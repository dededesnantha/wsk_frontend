@extends('front.layout')

@section('script')
  @include('front.component.script_ratting')  
@endsection

@section('content')  
    <section class="container">
      <div class="row">
        <div class="c-8" style="padding-top: 50px">
          <div class="text-center">
            @include('front.component.alert')                  
            <h1 id="{{str_replace(' ','_',@$optiomation['main_title'])}}" class="color-primary" style="font-family: 'Josefin Sans', sans-serif;">
        {{@$optiomation['main_title']}}            
            </h1>
            <div class="line color-primary"></div>
          </div>
          @include('front.component.breadcrumb')        
          <div class="row">
            
            <div>            
              <p style="padding-left:15px">
                {{ substr(strip_tags($list[0]->deskripsi_blog), 0,300)}}
                {{ substr(strip_tags($list[0]->deskripsi_product), 0,300)}}..
              </p>
            </div>
            <div style="width: 100%;background: #eee;box-shadow: 0 1px 1px rgba(0,0,0,0.3);margin: 10px 0;border-radius:2px;">
                @include('front.component.ratting')              
                <h3 style="margin: 10px;margin-left: 20px;" >
                  <a href="#judul" style="color: #444;font-weight: bolder;font-size: large;">{{@$optiomation['main_title']}}</a>
                </h3>
                <ul style="margin:5px 0;list-style: decimal;">
                  @foreach($list as $row)
                    <li><a href="#{{$row->slug_product.$row->slug_blog}}" style="color: #444;">{{$row->judul_product.$row->judul_blog}}</a></li>
                  @endforeach
                </ul>
              </div>
          </div>
          <div class="row">
            <h2 id="judul">{{@$optiomation['main_title']}}</h2>
          
      
            @include('front.component.list_tag')          
            <br>
            @include('front.component.give_review',['param'=>'tag'])

            <div class="col-12 m-auto">
               <?php echo $list->render(); ?>
            </div>

          </div>
        </div>
        
        @include('front.inc.sidebar')

      </div>
    </section>
@endsection
