<!DOCTYPE html>
<html lang="{{ $main['label']['en'] }}">
<head>
@if(trim($main['profile_website']->google_webmaster) != '')  
    <?= $main['profile_website']->google_webmaster; ?>  
@endif
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="{{$main['color']}}" />
    <meta name="apple-mobile-web-app-status-bar-style" content="{{$main['color']}}">
    @include('front.inc.optiomation')
  
  <link rel="icon" type="image/png" href="{{asset('image').'/'.$main['profile_website']->logo}}">
  
  <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">
  <link rel="stylesheet" type="text/css" href="{{asset('front/template2/font/style.css')}}?v={{$main['v']}}">
  <link rel="stylesheet" type="text/css" href="{{asset('front/template2/css/grid.css')}}?v={{$main['v']}}">
  <link rel="stylesheet" type="text/css" href="{{asset('front/template2/css/nav.css')}}?v={{$main['v']}}">
  <link rel="stylesheet" type="text/css" href="{{asset('front/template2/css/main.css')}}?v={{$main['v']}}">
  <link rel="stylesheet" type="text/css" href="{{asset('front/template2/slider.css')}}?v={{$main['v']}}">
  <link rel="stylesheet" type="text/css" href="{{asset('front/template2/style.css')}}?v={{$main['v']}}">

  @include('front.component.template_style')
  @if($main['component']['AMP'])
  <link rel="amphtml" href="{{ str_replace(url(''), url('').'/amp',Request::fullUrl() ) }}">  
  @endif
  @if(trim($main['profile_website']->google_analytics) != '')  
    <?= $main['profile_website']->google_analytics; ?>  
  @endif
  @if(trim($main['profile_website']->facebook_pixel) != '')  
    <?= $main['profile_website']->facebook_pixel; ?>  
  @endif
  @if(trim($main['profile_website']->tawk) != '')  
    <?= $main['profile_website']->tawk; ?>  
  @endif
@if(!empty($optiomation))

  <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "WebSite",
      "url": "{{ url('') }}"
    }    
    {
      "@context": "http://schema.org/",
      "@type": "WebSite",              
      "name": "{{ $optiomation['sitename'] }}",
      "url": "{{ url('') }}",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "{{ url('search') }}?search={search_term_string}",
        "query-input": "required name=search_term_string"
      } 
    }  
  </script>
  <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "PostalAddress",
      "streetAddress": "{{$main['profile_website']->alamat}}"
    }
  </script>
@endif
  @yield('script')
</head>
<body >
  @if(@Request::cookie('to_admin'))  
  <a href="{{url('apps#/app/dashboard')}}" style="height: 45px;width: 45px;background: #fff;border:4px solid #efefef;position: fixed;right: 5px;top:45%;border-radius: 100%;z-index: 99;box-shadow: 0px -1px 4px #9a9a9a"><i class="icon icon-settings" style="font-size: 19px;display: table;margin: auto;position: relative;top: 8px;color: #868686;font-weight: 700;"></i></a>
  @endif
  <div class="container">
    <div class="row">
      <div class="c-12">
        <div class="row">
          <div class="c-3 text-center">
            <a href="{{ url() }}" title="{{ $main['profile_website']->judul }}" style="height: 100%;display: grid;">
              <img src="{{asset('image').'/'.$main['profile_website']->logo}}" alt="{{ $main['profile_website']->judul }}" style="max-height: 80px" class="p-1 m-auto">
            </a>
          </div>
          <!-- <div style="display: inline;padding: 21px;position: absolute;"> -->
          <div class="c-9">
            <div class="row">
              <div class="c-12" style="padding-top: 12px">
                <div class="pull-left" style="font-family: 'Josefin Sans', sans-serif;">
                  @if(trim(@$main['wa']) != '')
                    {{ $main['label']['Contact'] }} : <a href="{{ @$main['wa'] }}">{{ @$main['wa_id'] }}</a>
                  @endif
                </div>
                <div class="pull-right">
                  @foreach($main['social_media'] as $social_media)
                    <a href="{{$social_media['link']}}" title="{{$social_media['title']}}"><img src="{{$social_media['img']}}" alt="{{$social_media['title']}}" width="25px" style="border-radius: 100%"></a>                    
                  @endforeach
                </div>
              </div>
            </div>
            <div style="padding: 25px 0" class="pull-right">
              <form method="get" action="{{url('search')}}" class="row">
                <div class="form-group">
                  <input type="search" name="search" class="form-control" placeholder="{{ $main['label']['Search'] }}" style="text-align: right;">
                </div>
                <button type="submit" style="color:#ADA996;background: transparent;font-size: 20px;font-weight: 300;border: 2px solid;border-radius: 4px;height: 45px;padding: 9px 10px;margin: 0px 2px;padding-top: 5px;"><i class="icon icon-magnifier"></i></button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <header id="header" class="container-fluid bg-primary">    
      <nav class="container bg-primary">
        <div class="row" style="text-align: right;"> 
          <label for="show-menu" class="show-menu color-white" style="line-height:50px;top: 7px;"><i class="icon icon-menu" style="font-size: 26px"></i></label>  
            <input type="checkbox" id="show-menu" role="button">
          <div class="c-12 row navigasi"> 
              <ul id="menu" class="p-0 nav" style="width: 100%;height: auto;position: relative;margin: auto;">
                @foreach($main['menu'] as $row)
                  <li class="nav">
                @if($row->link == 'kategori')
                    <a href="#" title="{{$row->judul}}">{{$row->judul}}</a>
                @else
                    <a href="{{$row->link}}" title="{{$row->judul}}">{{$row->judul}}</a>
                @endif
                @if($row->link == 'kategori')
                      <ul class="hidden nav">
                @foreach($main['parent'][$row->id_parent] as $key)
                            <li class="nav"><a href="{{url('link').'/'.$key->slug}}" title="{{$key->judul}}">{{$key->judul}}</a></li>
                @endforeach
                      </ul>
                @endif
                  </li>
                @endforeach
              </ul>
          </div>
        </div>
      </nav>
  </header>

  <main>
    @if($main['wa'] != '' )
       <a class="share_button" href="{{ $main['wa'] }}" title="whatsapp" style="position: fixed;bottom: 25px;left: 20px;z-index: 99;" target="_blank">
        <img src="{{ asset('img/wa2.png') }}" alt="whatsapp" style="border-radius: 100%;width: 50px;box-shadow: 1px 1px 16px -2px rgba(0,0,0,.3);position:relative;z-index: 1;">
          <span class="s_tampil">WhatsApp</span>      
      </a>
    @endif
    @yield('content')
  </main>

  <footer class="container-fluid">
    <div class="container p-4">     
      
      <div class="row">
        @for ($i = 1; $i <= 3; $i++)
          <div class="c-4 text-center">          
            @foreach($main['footer_kolom'.$i] as $row)
              @if ($row->template != null)              
                @include($row->template)
              @endif
            @endforeach
          </div>
        @endfor       
      </div>
      @if(count($main['menu_footer']) != 0)
      <div class="row">
        <div class="c-12 sub-footer" style="padding: 2.5px 15px;color: #fff">
            @foreach($main['menu_footer'] as $row)     
              | <a href="{{$row->link}}" title="{{$row->judul}}" style="font-family: 'Josefin Sans', sans-serif;color:#fff">{{$row->judul}}</a>
            @endforeach
        </div>
      </div>
      @endif
    </div>      
  </footer>
  <div class="container-fluid text-center color-white p-3 sub-footer">
    <small>&copy;<?= date('Y') ?> All Rights Reserved.Powered by 
      <span>
        <a href="https://www.tayatha.com/" title="tayatha" target="_blank" class="color-white">tayatha</a>
      </span>
    </small>
  </div>
 <script type='text/javascript'>
  //<![CDATA[
  document.addEventListener('copy', function (e){
      e.preventDefault();
    e.clipboardData.setData("text/plain", ""+window.location.href+"");
  })
  //]]>
  </script>
  @yield('js')
</body>
</html>
