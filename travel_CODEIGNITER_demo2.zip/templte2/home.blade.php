@extends('front.layout')
@section('script')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.8.5/tiny-slider.css">  
<script src="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.8.5/min/tiny-slider.js"></script>

<script src='https://www.google.com/recaptcha/api.js'></script>
<script src="{{asset('front/template2')}}/jquery-3.1.1.min.js" type="text/javascript" ></script>
<script>
  $(document).ready(function() {

  $('#add').click(function() {
  $('#input_add').append('<div class="form-group" id="input_add" style="margin-top: 10px"><input class="form-control" id="custom" name="custom_tour[]" type="text" placeholder="Your Tour" ></div>');
  });
  });
</script>
@endsection

@section('content')  
    @foreach($home as $row)
      @if($row->name == 'Slider')
          @include('front.inc.slider')      
      @endif
    @endforeach
    @include('front.component.alert')      
    <section class="container">
      <div class="row">
        <div class="c-8">
          @foreach($home as $row)
            @if($row->name == 'Profile')
               @include('front.inc.profile')
            @elseif($row->name == 'Product')
               @include('front.inc.product')
            @elseif($row->name == 'Special')
                @include('front.inc.special')
            @elseif($row->name == 'Transport')
                @include('front.inc.car_charter')               
            @elseif($row->name == 'Booking')
              @include('front.inc.booking')
            @elseif($row->name == 'Review')
              @include('front.inc.review')
            @endif          
          @endforeach
        </div>
        @include('front.inc.sidebar')        
      </div>
    </section>
@endsection
