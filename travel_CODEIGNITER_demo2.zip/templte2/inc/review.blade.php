@if (count($Review) != 0)                

<section  style="margin-bottom: 75px">
    <div class="row text-center">
        <div class="c-12">          
            <h1 id="{{str_replace(' ','_',$row->judul)}}" class="text-header color-primary">{{$row->judul}}</h1>
            <span class="line color-primary margin-bottom"> </span>
        </div>
    </div>
    <div class="row review" id="testi">
        @foreach ($Review as $reviews)                                
        <div class="col-lg-6 offset-lg-3">
            <div class="block"> 
                <div >
                    <div class="date">
                        <small class="color-primary"><i class="icon icon-user"></i> {{$reviews->name}}</small>
                    </div>
                    <h3>{{$reviews->subject}}</h3>
                    <div class="rating">
                        @for ($ii = 0; $ii < (int)$reviews->count; $ii++)                                                                                
                            <i class="icon-round fill"></i>
                        @endfor
                        
                        @for ($ii = 0; $ii < (5- (int)$reviews->count); $ii++)
                            <i class="icon-round"></i>
                        @endfor                            
                    </div>
                    <div class="date">
                        <meta content="{{$reviews->created_at}}">
                        <small><i class="icon icon-clock"></i> {{$reviews->filter_created_at}}</small>                               
                    </div>
                    <p style="width:100%">
                        {{$reviews->message}}                                
                    </p>
                </div>
            </div>                        
        </div>
        @endforeach
    </div>
    <div class="row m-t-50 text-center block">
        <div class="my-controls ">                        
            <button class="slider-prev bg-primary color-white button-primary"><i class="icon icon-arrow-left"></i></button>
            <button class="slider-next bg-primary color-white button-primary"><i class="icon icon-arrow-right"></i></button>
        </div>
    </div>

</section>
@endif

<script>
var slider = tns({
    "container": "#testi",
    "autoHeight": true,
    "items": 1,
    "swipeAngle": true,
    "speed": 400,  
    "autoplayTimeout":7000,
    "autoplay": true,
    "controls":false,
    "nav":false,
    "autoplayButtonOutput":false,
    "mouseDrag": true,
});
document.querySelector('.slider-next').onclick = function () { slider.goTo('next'); }; document.querySelector('.slider-prev').onclick = function () { slider.goTo('prev'); };
</script>