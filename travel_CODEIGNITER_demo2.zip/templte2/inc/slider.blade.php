    <div class="slider">
      <ul>
          @foreach($Slider as $slide)
            <li>
              <img src="{{asset('galeri').'/1328x650/'.$slide->gambar}}" alt="{{$slide->judul}}">
              @if(trim($slide->judul) != "")
                <div>
                  <span>
                    {{$slide->judul}}                      
                  </span>
                </div>
              @endif
            </li>
          @endforeach            
      </ul>
    </div>