          <section  style="margin-bottom: 75px">
            <div class="row text-center">
              <div class="c-12">          
                <h1 id="{{str_replace(' ','_',$row->judul)}}" class="text-header color-primary">{{$row->judul}}</h1>
                <span class="line color-primary margin-bottom"></span>
              </div>
            </div>
            <div class="row">            
              @foreach($Special  as $spesial)
              <article class="c-6" style="margin-bottom:20px">
                <div class="card-2 text-center">
                  <div class="card-2-image">
                    <a href="{{ $spesial['link'] }}" title="{{$spesial['title']}}">
                      <img src="{{$spesial['img_path'].'650x550'.$spesial['img']}}" alt="{{$spesial['title']}}">
                    </a> 
                  </div>
                  <div style="border-left: 1px solid #d1d1d1;border-right: 1px solid #d1d1d1;border-top: 1px solid #d1d1d1;">          
                    <a href="{{ $spesial['link'] }}" title="{{$spesial['title']}}">
                      <h2 style="margin-top: 0;padding-top: 20px;margin-bottom: 0;" class="font-secondary color-primary">{{$spesial['title']}}</h2>
                    </a>
                    <div class="card-2-content" style="display: grid;">
                      <p>
                        {{$spesial['description']}}                        
                      </p>
                    </div>
                    @if(round($spesial['price']) != 0)
                    <div class="card-2-content" style="padding:0 ;display: grid;">
                      <div class="list-price">
                        <small>Start From : </small>
                        <span>
                           {{$main['label']['Price Symbol']}} <?= number_format($spesial['price'],0,',','.'); ?>
                        </span>
                      </div>
                    </div>
                    @endif
                  </div>
                  <div style="margin: 0;">
                    <a href="{{ $spesial['link'] }}" title="{{$spesial['title']}}" class="card-2-button bg-primary color-white button-block p-2"><i class="icon icon-arrow-right"></i> {{ $main['label']['Read More'] }}</a>
                  </div>
                </div>
              </article>          
              @endforeach              
            </div>
          </section>
