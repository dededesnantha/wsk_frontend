        <aside class="c-4" >          
          <div class="container" style="height: 100%;width: 200%;position: absolute;background: #f9f9f9;border-left: 2px solid #efefef;z-index: -1"></div>
            <div style="padding:50px 10px 50px 25px">
            @foreach($sidebar as $row)              
                @if($row->role == 1)
                  <div class="p-1 color-primary" style="margin-bottom: 10px">
                    <div>
                      @if($row->judul != '')
                        <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                          {{$row->judul}}                    
                        </h2>
                      @endif
                      @foreach($main['social_media'] as $social_media)
                        <a href="{{$social_media['link']}}" title="{{$social_media['title']}}"><img src="{{$social_media['img']}}" alt="{{$social_media['title']}}" width="40px"></a>
                      @endforeach
                    </div>            
                  </div>  
                               
                @elseif($row->role == 2)
                <div class="p-1 color-primary" style="margin-bottom: 10px">                  
                  @if(trim($main['profile_website']->alamat) != '')
                    <div style="display: -webkit-box;padding: 10px;">
                      <i style="font-size: 45px;padding: 10px;" class="icon icon-location-pin"></i>
                      <div>
                        <strong>{{ $main['label']['Address'] }} :</strong><br>
                        <span>{{$main['profile_website']->alamat}}</span>
                      </div>
                    </div>
                  @endif
                 
                  @if(trim(@$main['wa']) != '')
                    <div style="display: -webkit-box;padding: 10px;">
                      <i style="font-size: 45px;padding: 10px;" class="icon icon-screen-smartphone"></i>
                      <div>
                        <strong>Phone :</strong><br>

                        <a href="{{ @$main['wa_id'] }}"><span>{{ @$main['wa_id'] }}</span></a>
                      </div>
                    </div>
                  @endif
                  @if(trim($main['profile_website']->email) != '')
                    <div style="display: -webkit-box;padding: 10px;">
                      <i style="font-size: 40px;padding: 15px;" class="icon icon-envelope"></i>
                      <div>
                        <strong>Email :</strong><br>
                        <a href="mailto:{{$main['profile_website']->email}}" class="color-primary"><span>{{$main['profile_website']->email}}</span></a>
                      </div>
                    </div>
                  @endif
                </div>

                @elseif($row->role == 3)
                <div class="p-1 color-primary" style="margin-bottom: 10px">
                  <div>
                    <a href="{{url('/')}}" title="{{$main['profile_website']->judul}}"><img src="{{url('image').'/'.$main['profile_website']->logo}}" alt="logo" style="max-height:75px"></a>
                  </div>            
                </div>              
                @elseif($row->role == 4)
                <div class="p-1 color-primary" style="margin-bottom: 10px">
                  <div>
                    @if($row->judul != '')                  
                    <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                      {{$row->judul}}
                    </h2>
                    @endif
                   <div>
                     <?= $main['profile_website']->deskripsi ?>
                   </div>
                  </div>            
                </div>              
                @elseif($row->role == 5)
                  <div class="p-1 color-primary" style="margin-bottom: 10px">
                    @foreach($row->data as $item )
                      <div style="position: relative;border-radius: 2px;overflow: hidden;margin-bottom: 10px;">
                        <img src="{{asset('gambar/500x300/'.$item->gambar)}}" alt="{{$item->judul}}" style="display: block;">
                        <a href="{{url('category/'.$item->slug)}}" title="{{$item->judul}}" style="position: absolute;bottom: 0;padding: 0;height: 100%;width: 100%;display: flex;background: rgba(0,0,0,0.2);">
                          <span style="font-size: 15.5px;background: rgba(0,0,0,0.7);padding: 5px 10px;margin: 10px auto auto 10px;border-radius: 5px;color: #eee;">{{$item->judul}}</span>
                        </a>                  
                      </div>
                    @endforeach
                  </div>                  
                @elseif($row->role == 7)
                <div class="p-1 color-primary" style="margin-bottom: 10px">
                  <div>
                    @if($row->judul != '')                  
                    <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                      {{$row->judul}}
                    </h2>
                    @endif                  
                    <ul style="padding: 0;list-style: none;margin-top: 2px">            
                      @foreach($row->data as $item )                      
                      <li style="display: flex;padding: 7px;border-bottom: 2px solid #efefef">
                        <a href="{{$item['link']}}" title="{{$item['title']}}" class="color-primary">
                          <span style="margin: auto 0;font-weight: 500;font-size: 16px;">
                            {{$item['title']}}
                          </span>
                        </a>
                      </li>
                      @endforeach                      
                    </ul>
                  </div>            
                </div>              
                @elseif($row->role == 8)
                <div class="p-1 color-primary" style="margin-bottom: 10px">
                  <div>
                    @if($row->judul != '')                  
                    <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                      {{$row->judul}}                  
                    </h2>
                    @endif                  
                    <ul style="padding: 0;list-style: none;margin-top: 2px">            
                      @foreach($main['menu'] as $key)  
                        @if($key->link != 'kategori')
                          <li style="display: flex;padding: 7px;border-bottom: 2px solid #efefef">
                            <a href="{{$key->link}}" title="{{$key->judul}}" class="color-primary">
                              <span style="margin: auto 0;font-weight: 500;font-size: 16px;">
                                {{$key->judul}}
                              </span>
                            </a>
                          </li>
                        @endif
                      @endforeach
                    </ul>
                  </div>            
                </div>              
                @elseif($row->role == 10)
                <div class="p-1 color-primary" style="margin-bottom: 10px">
                  <div>
                    @if($row->judul != '')
                    <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                      {{$row->judul}}
                    </h2>
                    @endif
                    <ul style="padding: 0;list-style: none;margin-top: 2px">            
                      @foreach($row->data as $item )
                      <li style="display: flex;padding: 7px;border-bottom: 2px solid #efefef">
                        <a href="{{url('link/'.$item->slug)}}" title="{{$item->judul}}"class="color-primary">
                          <span style="margin: auto 0;font-weight: 500;font-size: 16px;">
                            {{$item->judul}}
                          </span>
                        </a>
                      </li>
                      @endforeach
                    </ul>
                  </div>            
                </div>              
                @elseif($row->role == 11)
                  @if(trim($main['profile_website']->map) != '')
                    <div class="p-1 color-primary" style="margin-bottom: 10px">
                      <div>
                        @if($row->judul != '')
                        <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                          {{$row->judul}}                      
                        </h2>
                        @endif
                        <div style="max-height: 300px; overflow: hidden;">
                          <?= $main['profile_website']->map; ?>
                        </div>
                      </div>
                    </div>                  
                  @endif
                @elseif($row->role == 12)
                <div class="p-1 color-primary" style="margin-bottom: 10px">
                  <div>
                    @if($row->judul != '')
                      <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                        {{$row->judul}}                    
                      </h2>
                    @endif
                    <ul style="padding: 0;list-style: none;margin-top: 2px">            
                      @foreach($row->data as $item )                    
                      <li style="display: flex;padding: 7px;border-bottom: 2px solid #efefef">
                        <a href="{{url('blog/'.$item->slug)}}" title="{{$item->judul}}" class="color-primary">
                          <span style="margin: auto 0;font-weight: 500;font-size: 16px;">
                            {{$item->judul}}
                          </span>
                        </a>
                      </li>
                      @endforeach
                    </ul>
                  </div>            
                </div>               
                @elseif($row->role == 13)
                  @if(trim($main['profile_website']->tripadvisor) != '')
                  <div class="p-1 color-primary" style="margin-bottom: 10px">
                    <div>
                      @if($row->judul != '')                    
                      <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                        {{$row->judul}}
                      </h2>
                      @endif                  
                     <div>
                      <?= $main['profile_website']->tripadvisor; ?>                       
                     </div>
                    </div>            
                  </div>                 
                  @endif          
                @elseif($row->role == 14)
                  @foreach($row->data as $key) 
                    @if($key['data'] != null)
                      <div class="p-1 color-primary" style="margin-bottom: 10px">
                        <div>
                          <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                            {{$key['name']}}
                          </h2>
                          <ul style="padding: 0;list-style: none;margin-top: 2px">            
                            @foreach($key['data'] as $rows)                          
                            <li style="display: flex;padding: 7px;border-bottom: 2px solid #efefef">
                              <a href="{{url('link/'.$rows->slug)}}" title="{{$rows->judul}}" class="color-primary">
                                <span style="margin: auto 0;font-weight: 500;font-size: 16px;">
                                  {{$rows->judul}}
                                </span>
                              </a>
                            </li>
                            @endforeach                            
                          </ul>
                        </div>            
                      </div>                  
                    @endif
                  @endforeach                
                @elseif($row->role == 15)
                  @if(!empty($row->data))
                  <div class="p-1 color-primary" style="margin-bottom: 10px">
                    <div>
                      <h2 class="font-secondary color-primary" style="margin: 0;margin-left: 5px">
                        Patner                      
                      </h2>
                     <div>
                        @foreach($row->data as $rows)
                          <a href="{{$rows['link']}}" title="{{$rows['judul']}}" style="margin-bottom: 10px;background: #fff;padding: 0 11px;margin-right: 7px;border: 1px solid #e4e4e4;border-radius: 3px;display: inline-flex;">
                            {{$rows['judul']}}
                          </a>
                        @endforeach
                     </div> 
                    </div>            
                  </div>                
                  @endif                  
                @endif                          
            @endforeach
            </div>
          </div>
        </aside>