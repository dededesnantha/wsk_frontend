    <section  style="margin-bottom: 75px;padding-top: 50px">
      <div class="row">
        <div class="c-12">
          <h1 class="font-secondary color-primary" style="line-height: 1.4;margin-top: 0">{{$row->judul}}</h1>
          <div style="line-height: 1.7;letter-spacing: 1.5px;text-align: justify;">
          <img src="{{asset('gambar/350x400/'.$main['profile_website']->gambar)}}" alt="{{$main['profile_website']->judul}}" class="profile-img">
          <?= $main['profile_website']->deskripsi; ?>
          </div>
         
        </div>
        <div class="c-6" >
          
        </div>
        <div class="c-12">
          <div style="line-height: 1.7;letter-spacing: 1.5px;text-align: justify;">
            
          </div>
            @foreach($main['contact'] as $profile_contact)    
              @if($profile_contact['role'] != 0)              
                  <a href="{{$profile_contact['link']}}" title="{{$profile_contact['title']}}" target="_blank"><img src="{{$profile_contact['img']}}" alt="{{$profile_contact['title']}}" width="35px"></a>
              @endif
            @endforeach      
        </div>
      </div>
    </section>