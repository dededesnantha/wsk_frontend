      <section  style="margin-bottom: 75px">
        <div class="row text-center">
          <div class="c-12">          
            <h1 id="{{str_replace(' ','_',$row->judul)}}" class="text-header color-primary">{{$row->judul}}</h1>
            <span class="line color-primary margin-bottom"> </span>
          </div>
        </div>
        <div class="row">      
          @foreach($Transport as $key)
          <div class="c-6" style="margin-bottom:20px">
            <div class="card-2">
              <div class="card-2-image" style="height: 200px">
                <a href="#" title="{{$key->judul}}">
                  <img src="{{asset('gambar/344x250').'/'.$key->gambar}}" alt="{{$key->judul}}" style="width: 100%">            
                </a>  
              </div>                  
                <h2 id="{{str_replace(' ','_',$key->judul)}}" class="font-secondary color-primary text-center">{{$key->judul}}</h2>                          
              <div class="card-2-content">
                <div>
                  <?= $key->deskripsi ?>
                </div>
                @if($transport_button == true)
                  <div class="text-center">
                    <a href="{{url('booking.html')}}" title="{{ $main['label']['Booking'] }}" class="bg-primary color-white p-2"><i class="icon icon-arrow-right"></i> {{ $main['label']['Booking'] }}</a>
                  </div>
                @endif
              </div>
            </div>
          </div>
          @endforeach
        </div>
      </section>