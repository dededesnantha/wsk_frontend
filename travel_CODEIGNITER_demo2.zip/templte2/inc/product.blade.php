          <section  style="margin-bottom: 75px">
            <div class="row text-center">
              <div class="c-12">          
                <h1 id="{{str_replace(' ','_',$row->judul)}}" class="text-header color-primary">{{$row->judul}}</h1>
                <span class="line color-primary margin-bottom"> </span>
              </div>
            </div>
            <div class="row">

              @foreach($Product as $produk)
              <article class="c-6" style="margin-bottom:20px">
                <div class="card-1"> 
                  <a href="{{url('category').'/'.$produk->slug}}" title="{{$produk->judul}}">
                    <img src="{{asset('gambar/350x500').'/'.$produk->gambar}}" alt="{{$produk->judul}}">
                  </a>
                  <div>
                    <a href="{{url('category').'/'.$produk->slug}}" title="{{$produk->judul}}">
                      <h2 id="{{str_replace(' ','_',$produk->judul)}}" class="color-white font-secondary bg-primary p-2" style="display:initial;margin:0">{{$produk->judul}}</h2>
                    </a>
                    @if(trim($produk->seo_deskripsi) != '')
                      <div>
                        <p style="color:#000">
                          <?= substr(strip_tags($produk->seo_deskripsi), 0,150) ?>
                        </p>
                        <div class="text-right">
                          <a href="{{url('category').'/'.$produk->slug}}" title="{{$produk->judul}}" class="color-primary">{{ $main['label']['View More'] }} <i class="icon icon-action-redo"></i></a>
                        </div>
                      </div>
                    @endif
                  </div>
                </div>
              </article>
              @endforeach
            </div>
          </section>