@if($row->judul != '')
		<h3 class="font-secondary color-white" style="font-size: 24.5px;font-weight: 500">{{$row->judul}}</h3>
@endif		
		<p class="color-white text-left">{{ $main['label']['Address'] }} : {{$main['profile_website']->alamat}}</p>		
