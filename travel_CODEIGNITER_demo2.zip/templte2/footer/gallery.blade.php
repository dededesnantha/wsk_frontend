		@if($row->judul != '')		
			<h3 class="font-secondary color-white" style="font-size: 24.5px;font-weight: 500">{{$row->judul}}</h3>
		@endif
		<div class="slider">
			<ul>
				@foreach($main['footer_slider'][$row->id_galeri_kategori] as $key)	    		
					<li>
						<img src="{{asset('galeri/300x250').'/'.$key->gambar}}" alt="{{$key->judul}}">	    		
					</li>
				@endforeach            
			</ul>
		</div>
	