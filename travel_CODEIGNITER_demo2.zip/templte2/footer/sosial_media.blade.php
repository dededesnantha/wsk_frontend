@if($row->judul != '')
		<h3 class="font-secondary color-white" style="font-size: 24.5px;font-weight: 500">{{$row->judul}}</h3>	
@endif
@foreach($main['social_media'] as $social_media)
		<a href="{{$social_media['link']}}" title="{{$social_media['title']}}"><img src="{{$social_media['img']}}" alt="{{$social_media['title']}}" width="40px"></a>
@endforeach
		<br>
