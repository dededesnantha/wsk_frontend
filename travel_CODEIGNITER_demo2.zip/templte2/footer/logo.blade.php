		<a href="{{url('/')}}" title="{{$main['profile_website']->judul}}">
			<img src="{{url('image').'/'.$main['profile_website']->logo}}" alt="logo" width="120px"></a>
		