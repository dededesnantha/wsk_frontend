@if($row->judul != '')
		<h3 class="font-secondary color-white" style="font-size: 24.5px;font-weight: 500">{{$row->judul}}</h3>
@endif		

@foreach($main['contact'] as $contacts)    
	
	<div style="text-align: left;padding-left: 24px;">
		
	@if($contacts['role'] != 0)	
		@if(!$contacts['image_null'])
				<a class="color-white" href="{{$contacts['link']}}" title="{{$contacts['title']}}" target="_blank">
					<img style="position: relative;top: 10px;" src="{{$contacts['img']}}" alt="{{$contacts['title']}}" width="30px">
				</a>
		@endif
			<span class="color-white">{{$contacts['title']}} :</span> <a class="color-white" href="{{$contacts['link']}}" title="{{$contacts['title']}}" target="_blank"><span>{{$contacts['id']}}</span></a><br>
	@else

		@if(!$contacts['image_null'])
			  	<img style="position: relative;top: 10px;" src="{{$contacts['img']}}" alt="{{$contacts['title']}}" width="30px">
		@endif
			<span class="color-white">{{$contacts['title']}} : <span >{{$contacts['id']}}</span></span><br>
	@endif

	</div>
@endforeach
		<div style="text-align: left;padding-left: 24px;">
			<p class="color-white text-left">{{ $main['label']['Address'] }} : <span>{{$main['profile_website']->alamat}} </span></p>
		</div>
		
<hr>